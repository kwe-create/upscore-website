import Link from "next/link";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import {
  getProductBySlug,
  getReviewsForProduct,
  getRelatedProducts,
} from "@/lib/queries";
import { ProductGallery } from "@/components/ProductGallery";
import { AddToCartPanel } from "@/components/AddToCartPanel";
import { ReviewsSection } from "@/components/ReviewsSection";
import { ProductCard } from "@/components/ProductCard";
import { Stars, CheckIcon, ArrowRight } from "@/components/Icons";

export const dynamic = "force-dynamic";

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const product = await getProductBySlug(slug);
  if (!product) return { title: "Not found — UPSCORE" };
  return {
    title: `${product.name} — UPSCORE`,
    description: product.tagline,
  };
}

export default async function ProductPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const product = await getProductBySlug(slug);
  if (!product) notFound();

  const [reviews, related] = await Promise.all([
    getReviewsForProduct(product.id),
    getRelatedProducts(product.collection, product.id),
  ]);

  return (
    <div className="mx-auto max-w-7xl px-5 sm:px-8 py-8">
      {/* Breadcrumb */}
      <nav className="mb-8 flex items-center gap-2 text-sm text-ink/50">
        <Link href="/" className="hover:text-ink transition-colors">
          Home
        </Link>
        <span>/</span>
        <Link href="/shop" className="hover:text-ink transition-colors">
          Shop
        </Link>
        <span>/</span>
        <span className="text-ink/80">{product.name}</span>
      </nav>

      <div className="grid gap-10 lg:grid-cols-2">
        <div className="animate-fade-up">
          <ProductGallery images={product.images} name={product.name} />
        </div>

        <div className="animate-fade-up delay-100">
          <div className="flex items-center gap-3">
            <span className="rounded-full bg-plum/10 px-3 py-1 text-xs font-semibold uppercase tracking-wider text-plum">
              {product.category}
            </span>
            <span className="rounded-full bg-sand px-3 py-1 text-xs font-semibold uppercase tracking-wider text-ink/60">
              {product.collection}
            </span>
          </div>

          <h1 className="mt-4 font-display text-4xl font-semibold tracking-tight sm:text-5xl">
            {product.name}
          </h1>
          <p className="mt-3 text-lg text-ink/60">{product.tagline}</p>

          <div className="mt-4 flex items-center gap-2">
            <Stars rating={product.rating / 10} />
            <span className="text-sm font-medium">
              {(product.rating / 10).toFixed(1)}
            </span>
            <span className="text-sm text-ink/45">
              ({product.reviewCount}{" "}
              {product.reviewCount === 1 ? "review" : "reviews"})
            </span>
          </div>

          <AddToCartPanel product={product} />

          <p className="mt-6 leading-relaxed text-ink/70">
            {product.description}
          </p>

          {/* Platforms */}
          <div className="mt-6">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-ink/50">
              Works across
            </h3>
            <div className="mt-2 flex flex-wrap gap-2">
              {product.platforms.map((p) => (
                <span
                  key={p}
                  className="rounded-full border border-sand bg-cream px-3 py-1.5 text-sm font-medium"
                >
                  {p}
                </span>
              ))}
            </div>
          </div>

          {/* Features */}
          <div className="mt-8 grid gap-6 sm:grid-cols-2">
            <div>
              <h3 className="font-display text-lg font-semibold">
                What&apos;s included
              </h3>
              <ul className="mt-3 space-y-2.5">
                {product.features.map((f) => (
                  <li key={f} className="flex items-start gap-2.5 text-sm text-ink/75">
                    <span className="mt-0.5 flex h-5 w-5 flex-shrink-0 items-center justify-center rounded-full bg-coral/15 text-coral">
                      <CheckIcon className="w-3 h-3" />
                    </span>
                    {f}
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <h3 className="font-display text-lg font-semibold">
                You&apos;ll receive
              </h3>
              <ul className="mt-3 space-y-2.5">
                {product.deliverables.map((d) => (
                  <li key={d} className="flex items-start gap-2.5 text-sm text-ink/75">
                    <span className="mt-0.5 flex h-5 w-5 flex-shrink-0 items-center justify-center rounded-full bg-plum/15 text-plum">
                      <CheckIcon className="w-3 h-3" />
                    </span>
                    {d}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>

      {/* Reviews */}
      <div className="mt-20">
        <ReviewsSection
          productId={product.id}
          initialReviews={reviews}
          rating={product.rating}
        />
      </div>

      {/* Related */}
      {related.length > 0 && (
        <div className="mt-20">
          <div className="flex items-end justify-between">
            <h2 className="font-display text-3xl font-semibold tracking-tight">
              You might also like
            </h2>
            <Link
              href="/shop"
              className="inline-flex items-center gap-1.5 text-sm font-semibold hover:text-coral transition-colors"
            >
              All plans <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
          <div className="mt-8 grid grid-cols-2 gap-x-6 gap-y-10 lg:grid-cols-3">
            {related.map((p, i) => (
              <ProductCard key={p.id} product={p} index={i} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
