import { CheckoutClient } from "@/components/CheckoutClient";

export const metadata = {
  title: "Checkout — UPSCORE",
};

export default function CheckoutPage() {
  return <CheckoutClient />;
}
