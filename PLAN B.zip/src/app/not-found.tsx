import Link from "next/link";
import { ArrowRight } from "@/components/Icons";

export default function NotFound() {
  return (
    <div className="mx-auto flex max-w-2xl flex-col items-center px-5 py-32 text-center">
      <span className="font-display text-8xl font-bold text-coral">404</span>
      <h1 className="mt-4 font-display text-3xl font-semibold">
        This page went off-grid
      </h1>
      <p className="mt-3 text-ink/60">
        The page you&apos;re looking for doesn&apos;t exist — but your next
        growth plan does.
      </p>
      <Link
        href="/shop"
        className="mt-6 inline-flex items-center gap-2 rounded-full bg-ink px-6 py-3 text-sm font-semibold text-cream hover:bg-ink/90 transition-all hover:gap-3"
      >
        Browse plans <ArrowRight className="w-4 h-4" />
      </Link>
    </div>
  );
}
