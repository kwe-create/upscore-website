import { db } from "@/db";
import { reviews, products } from "@/db/schema";
import { eq, sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { productId, author, handle, rating, title, body: text } = body;

    if (!productId || !author || !rating || !title || !text) {
      return Response.json(
        { ok: false, error: "Missing required fields" },
        { status: 400 },
      );
    }

    const cleanRating = Math.max(1, Math.min(5, Number(rating)));

    const [inserted] = await db
      .insert(reviews)
      .values({
        productId: Number(productId),
        author: String(author).slice(0, 80),
        handle: String(handle || "@creator").slice(0, 60),
        avatar: null,
        rating: cleanRating,
        title: String(title).slice(0, 120),
        body: String(text).slice(0, 1000),
      })
      .returning();

    // Recompute aggregate rating
    const [agg] = await db
      .select({
        avg: sql<number>`coalesce(avg(${reviews.rating}), 0)`,
        count: sql<number>`count(*)`,
      })
      .from(reviews)
      .where(eq(reviews.productId, Number(productId)));

    await db
      .update(products)
      .set({
        rating: Math.round(Number(agg.avg) * 10),
        reviewCount: Number(agg.count),
      })
      .where(eq(products.id, Number(productId)));

    return Response.json({
      ok: true,
      review: {
        ...inserted,
        createdAt: inserted.createdAt.toISOString(),
      },
    });
  } catch (err) {
    return Response.json({ ok: false, error: String(err) }, { status: 500 });
  }
}
