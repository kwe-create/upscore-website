import { db } from "@/db";
import { contactMessages } from "@/db/schema";

export const dynamic = "force-dynamic";

const TOPICS = new Set(["support", "sales", "billing", "general"]);

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { name, email, topic, message } = body;

    if (!name || !email || !message) {
      return Response.json(
        { ok: false, error: "Please fill in your name, email, and message." },
        { status: 400 },
      );
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(email))) {
      return Response.json(
        { ok: false, error: "Enter a valid email address." },
        { status: 400 },
      );
    }

    const cleanTopic =
      typeof topic === "string" && TOPICS.has(topic) ? topic : "support";

    const [inserted] = await db
      .insert(contactMessages)
      .values({
        name: String(name).slice(0, 120),
        email: String(email).slice(0, 160),
        topic: cleanTopic,
        message: String(message).slice(0, 2000),
      })
      .returning({ id: contactMessages.id });

    return Response.json({
      ok: true,
      id: inserted.id,
      routedTo:
        cleanTopic === "support"
          ? "feliciarhodes@gmail.com"
          : "feliciarhodes@gmail.com",
    });
  } catch (err) {
    return Response.json({ ok: false, error: String(err) }, { status: 500 });
  }
}
