import { db } from "@/db";
import { orders } from "@/db/schema";
import type { CartItem } from "@/lib/types";

export const dynamic = "force-dynamic";

const PROMO_CODES: Record<string, number> = {
  CREATOR10: 0.1,
  LAUNCH20: 0.2,
  UPSCORE15: 0.15,
};

function makeReference() {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let s = "";
  for (let i = 0; i < 6; i++)
    s += chars[Math.floor(Math.random() * chars.length)];
  return `UPS-${s}`;
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const {
      email,
      fullName,
      company,
      items,
      promo,
      paymentMethod,
      payerEmail,
    }: {
      email: string;
      fullName: string;
      company?: string;
      items: CartItem[];
      promo?: string;
      paymentMethod?: string;
      payerEmail?: string;
    } = body;

    const method = paymentMethod === "paypal" ? "paypal" : "card";

    if (!email || !fullName || !Array.isArray(items) || items.length === 0) {
      return Response.json(
        { ok: false, error: "Missing required checkout fields" },
        { status: 400 },
      );
    }

    const subtotal = items.reduce(
      (sum, i) => sum + i.price * i.quantity,
      0,
    );

    let discount = 0;
    const code = (promo || "").trim().toUpperCase();
    if (code && PROMO_CODES[code]) {
      discount = Math.round(subtotal * PROMO_CODES[code]);
    }

    const total = subtotal - discount;
    const reference = makeReference();

    await db.insert(orders).values({
      reference,
      email: String(email).slice(0, 160),
      fullName: String(fullName).slice(0, 120),
      company: company ? String(company).slice(0, 160) : null,
      items: items.map((i) => ({
        productId: i.productId,
        name: i.name,
        price: i.price,
        quantity: i.quantity,
      })),
      subtotal,
      discount,
      total,
      paymentMethod: method,
      payerEmail:
        method === "paypal" && payerEmail
          ? String(payerEmail).slice(0, 160)
          : null,
      status: "paid",
    });

    return Response.json({
      ok: true,
      reference,
      subtotal,
      discount,
      total,
      paymentMethod: method,
      paypalEmail: "kbett8917@gmail.com",
    });
  } catch (err) {
    return Response.json({ ok: false, error: String(err) }, { status: 500 });
  }
}

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const promo = (searchParams.get("promo") || "").trim().toUpperCase();
  const rate = PROMO_CODES[promo] ?? 0;
  return Response.json({ ok: true, valid: rate > 0, rate });
}
