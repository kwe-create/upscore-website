import { db } from "@/db";
import { products, reviews, orders } from "@/db/schema";
import { seedProducts, seedReviews } from "@/lib/seed-data";
import { sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function POST() {
  try {
    await db.execute(sql`TRUNCATE TABLE ${orders} RESTART IDENTITY CASCADE`);
    await db.execute(sql`TRUNCATE TABLE ${reviews} RESTART IDENTITY CASCADE`);
    await db.execute(sql`TRUNCATE TABLE ${products} RESTART IDENTITY CASCADE`);

    const inserted = await db
      .insert(products)
      .values(seedProducts)
      .returning({ id: products.id, slug: products.slug });

    const slugToId = new Map(inserted.map((p) => [p.slug, p.id]));

    const reviewRows = seedReviews
      .map((r) => {
        const productId = slugToId.get(r.productSlug);
        if (!productId) return null;
        return {
          productId,
          author: r.author,
          handle: r.handle,
          avatar: null,
          rating: r.rating,
          title: r.title,
          body: r.body,
        };
      })
      .filter((r): r is NonNullable<typeof r> => r !== null);

    if (reviewRows.length) {
      await db.insert(reviews).values(reviewRows);
    }

    return Response.json({
      ok: true,
      products: inserted.length,
      reviews: reviewRows.length,
    });
  } catch (err) {
    console.error("Seed failed", err);
    return Response.json(
      { ok: false, error: String(err) },
      { status: 500 },
    );
  }
}

export async function GET() {
  return POST();
}
