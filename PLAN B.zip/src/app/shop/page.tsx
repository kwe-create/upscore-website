import { getAllProducts } from "@/lib/queries";
import { ShopClient } from "@/components/ShopClient";

export const dynamic = "force-dynamic";

export default async function ShopPage({
  searchParams,
}: {
  searchParams: Promise<{ collection?: string }>;
}) {
  const { collection } = await searchParams;
  const products = await getAllProducts();
  const valid = ["Growth", "Content", "Strategy"];
  const initialCollection =
    collection && valid.includes(collection) ? collection : undefined;

  return (
    <ShopClient products={products} initialCollection={initialCollection} />
  );
}
