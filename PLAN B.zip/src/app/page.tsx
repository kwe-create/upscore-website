import Link from "next/link";
import Image from "next/image";
import { getFeaturedProducts, getAllProducts } from "@/lib/queries";
import { ProductCard } from "@/components/ProductCard";
import { Marquee } from "@/components/Marquee";
import { ContactSection } from "@/components/ContactSection";
import { ArrowRight, CheckIcon, Stars } from "@/components/Icons";

export const dynamic = "force-dynamic";

const collections = [
  {
    name: "Growth",
    href: "/shop?collection=Growth",
    image: "/images/growth.jpg",
    desc: "Scale your reach with data-driven management.",
  },
  {
    name: "Content",
    href: "/shop?collection=Content",
    image: "/images/video.jpg",
    desc: "Scroll-stopping video, edited and ready to post.",
  },
  {
    name: "Strategy",
    href: "/shop?collection=Strategy",
    image: "/images/strategy.jpg",
    desc: "Brand identity and planning that sets you apart.",
  },
];

const steps = [
  {
    n: "01",
    title: "Pick your plan",
    body: "Choose the services that match where you are and where you're headed.",
  },
  {
    n: "02",
    title: "Onboard in 48h",
    body: "We learn your voice, audit your channels, and build your content system.",
  },
  {
    n: "03",
    title: "Watch it grow",
    body: "We handle the work. You get reports, results, and your time back.",
  },
];

export default async function HomePage() {
  const [featured, all] = await Promise.all([
    getFeaturedProducts(),
    getAllProducts(),
  ]);
  const featuredList = featured.length ? featured : all.slice(0, 4);

  return (
    <>
      {/* HERO */}
      <section className="relative overflow-hidden">
        <div className="mx-auto max-w-7xl px-5 sm:px-8 pt-10 pb-16 sm:pt-16 sm:pb-24">
          <div className="grid items-center gap-12 lg:grid-cols-2">
            <div className="animate-fade-up">
              <span className="inline-flex items-center gap-2 rounded-full border border-ink/10 bg-cream/60 px-4 py-1.5 text-xs font-semibold uppercase tracking-wider text-ink/70 backdrop-blur">
                <span className="h-2 w-2 rounded-full bg-coral animate-pulse" />
                Now onboarding creators for 2026
              </span>
              <h1 className="mt-6 font-display text-5xl font-semibold leading-[1.05] tracking-tight sm:text-6xl lg:text-7xl text-balance">
                Grow your{" "}
                <span className="relative inline-block text-coral">
                  audience
                  <svg
                    className="absolute -bottom-2 left-0 w-full"
                    viewBox="0 0 200 12"
                    fill="none"
                    preserveAspectRatio="none"
                  >
                    <path
                      d="M2 9C50 3 150 3 198 9"
                      stroke="#ff5a5f"
                      strokeWidth="3"
                      strokeLinecap="round"
                    />
                  </svg>
                </span>
                , not your to-do list.
              </h1>
              <p className="mt-6 max-w-md text-lg text-ink/60 leading-relaxed">
                UPSCORE is the social media team behind ambitious content
                creators. We plan, produce, and manage — so you can create
                what you love and let the numbers take care of themselves.
              </p>
              <div className="mt-8 flex flex-wrap items-center gap-4">
                <Link
                  href="/shop"
                  className="group inline-flex items-center gap-2 rounded-full bg-ink px-7 py-4 text-sm font-semibold text-cream transition-all hover:gap-3 hover:bg-ink/90"
                >
                  Shop plans
                  <ArrowRight className="w-4 h-4" />
                </Link>
                <Link
                  href="/shop?collection=Content"
                  className="inline-flex items-center gap-2 rounded-full border border-ink/15 px-7 py-4 text-sm font-semibold text-ink transition-colors hover:bg-sand"
                >
                  See content services
                </Link>
              </div>
              <div className="mt-10 flex items-center gap-6">
                <div className="flex -space-x-3">
                  {["#ff5a5f", "#6b4de6", "#f0a500", "#2dd4bf"].map((c, i) => (
                    <div
                      key={i}
                      className="flex h-10 w-10 items-center justify-center rounded-full border-2 border-cream text-xs font-bold text-white"
                      style={{ backgroundColor: c }}
                    >
                      {["MK", "JD", "AB", "SR"][i]}
                    </div>
                  ))}
                </div>
                <div>
                  <Stars rating={5} className="mb-0.5" />
                  <p className="text-sm text-ink/60">
                    <span className="font-semibold text-ink">1,400+</span>{" "}
                    creators growing with us
                  </p>
                </div>
              </div>
            </div>

            <div className="relative animate-fade-up delay-200">
              <div className="relative aspect-[4/5] overflow-hidden rounded-[2rem] shadow-2xl">
                <Image
                  src="/images/hero.jpg"
                  alt="Content creator at work"
                  fill
                  priority
                  sizes="(max-width: 1024px) 100vw, 50vw"
                  className="object-cover"
                />
              </div>
              <div className="absolute -left-4 top-10 animate-float rounded-2xl bg-cream p-4 shadow-xl">
                <p className="text-xs text-ink/50">Followers this month</p>
                <p className="font-display text-2xl font-bold text-coral">
                  +34,812
                </p>
              </div>
              <div
                className="absolute -right-4 bottom-16 animate-float rounded-2xl bg-cream p-4 shadow-xl"
                style={{ animationDelay: "2s" }}
              >
                <p className="text-xs text-ink/50">Avg. engagement</p>
                <p className="font-display text-2xl font-bold text-plum">
                  9.4%
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Marquee />

      {/* COLLECTIONS */}
      <section className="mx-auto max-w-7xl px-5 sm:px-8 py-20">
        <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4">
          <div>
            <span className="text-xs font-semibold uppercase tracking-wider text-plum">
              Curated for creators
            </span>
            <h2 className="mt-2 font-display text-4xl font-semibold tracking-tight sm:text-5xl">
              Shop by collection
            </h2>
          </div>
          <Link
            href="/shop"
            className="inline-flex items-center gap-1.5 text-sm font-semibold text-ink hover:text-coral transition-colors"
          >
            View all plans <ArrowRight className="w-4 h-4" />
          </Link>
        </div>

        <div className="mt-10 grid gap-6 md:grid-cols-3">
          {collections.map((c, i) => (
            <Link
              key={c.name}
              href={c.href}
              className="group relative aspect-[3/4] overflow-hidden rounded-2xl hover-lift animate-fade-up"
              style={{ animationDelay: `${i * 80}ms` }}
            >
              <Image
                src={c.image}
                alt={c.name}
                fill
                sizes="(max-width: 768px) 100vw, 33vw"
                className="object-cover transition-transform duration-700 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-ink/80 via-ink/10 to-transparent" />
              <div className="absolute inset-x-0 bottom-0 p-6 text-cream">
                <h3 className="font-display text-2xl font-semibold">{c.name}</h3>
                <p className="mt-1 text-sm text-cream/80">{c.desc}</p>
                <span className="mt-3 inline-flex items-center gap-1.5 text-sm font-semibold text-coral">
                  Explore <ArrowRight className="w-4 h-4" />
                </span>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* FEATURED PRODUCTS */}
      <section className="bg-blush/40">
        <div className="mx-auto max-w-7xl px-5 sm:px-8 py-20">
          <div className="text-center max-w-2xl mx-auto">
            <span className="text-xs font-semibold uppercase tracking-wider text-plum">
              Creator favorites
            </span>
            <h2 className="mt-2 font-display text-4xl font-semibold tracking-tight sm:text-5xl">
              Plans that do the heavy lifting
            </h2>
            <p className="mt-4 text-ink/60">
              Hand-picked by our team, loved by thousands of creators. Everything
              you need to show up consistently and grow.
            </p>
          </div>
          <div className="mt-12 grid grid-cols-2 gap-x-6 gap-y-10 lg:grid-cols-4">
            {featuredList.map((p, i) => (
              <ProductCard key={p.id} product={p} index={i} />
            ))}
          </div>
        </div>
      </section>

      {/* HOW IT WORKS */}
      <section className="mx-auto max-w-7xl px-5 sm:px-8 py-20">
        <div className="grid gap-12 lg:grid-cols-2 lg:items-center">
          <div className="relative aspect-square overflow-hidden rounded-[2rem] shadow-xl">
            <Image
              src="/images/content.jpg"
              alt="Content creation"
              fill
              sizes="(max-width: 1024px) 100vw, 50vw"
              className="object-cover"
            />
          </div>
          <div>
            <span className="text-xs font-semibold uppercase tracking-wider text-plum">
              How it works
            </span>
            <h2 className="mt-2 font-display text-4xl font-semibold tracking-tight sm:text-5xl">
              Effortless from day one
            </h2>
            <div className="mt-10 space-y-8">
              {steps.map((s) => (
                <div key={s.n} className="flex gap-5">
                  <span className="font-display text-2xl font-bold text-coral">
                    {s.n}
                  </span>
                  <div>
                    <h3 className="font-display text-xl font-semibold">
                      {s.title}
                    </h3>
                    <p className="mt-1 text-ink/60">{s.body}</p>
                  </div>
                </div>
              ))}
            </div>
            <ul className="mt-10 grid grid-cols-2 gap-3">
              {[
                "No long contracts",
                "Dedicated manager",
                "On-brand every time",
                "Real, human support",
              ].map((f) => (
                <li key={f} className="flex items-center gap-2 text-sm text-ink/70">
                  <span className="flex h-5 w-5 items-center justify-center rounded-full bg-coral/15 text-coral">
                    <CheckIcon className="w-3 h-3" />
                  </span>
                  {f}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      {/* CONTACT */}
      <ContactSection />

      {/* CTA */}
      <section className="mx-auto max-w-7xl px-5 sm:px-8 pb-8 pt-20">
        <div className="relative overflow-hidden rounded-[2.5rem] bg-ink px-8 py-16 text-center text-cream sm:px-16 sm:py-24">
          <div className="absolute -left-20 -top-20 h-64 w-64 rounded-full bg-coral/30 blur-3xl" />
          <div className="absolute -bottom-20 -right-20 h-64 w-64 rounded-full bg-plum/30 blur-3xl" />
          <div className="relative">
            <h2 className="font-display text-4xl font-semibold tracking-tight sm:text-5xl text-balance">
              Your best content era starts now.
            </h2>
            <p className="mx-auto mt-4 max-w-xl text-cream/70">
              Join 1,400+ creators who traded burnout for a real growth team.
              Pick a plan and we&apos;ll take it from here.
            </p>
            <Link
              href="/shop"
              className="mt-8 inline-flex items-center gap-2 rounded-full bg-coral px-8 py-4 text-sm font-semibold text-white transition-all hover:gap-3 hover:bg-coral/90"
            >
              Explore all plans <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </section>
    </>
  );
}
