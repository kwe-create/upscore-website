import {
  pgTable,
  serial,
  text,
  integer,
  timestamp,
  jsonb,
  boolean,
  varchar,
} from "drizzle-orm/pg-core";

export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  slug: varchar("slug", { length: 160 }).notNull().unique(),
  name: text("name").notNull(),
  tagline: text("tagline").notNull(),
  description: text("description").notNull(),
  category: varchar("category", { length: 80 }).notNull(),
  billing: varchar("billing", { length: 40 }).notNull().default("monthly"),
  price: integer("price").notNull(), // cents
  compareAtPrice: integer("compare_at_price"), // cents
  featured: boolean("featured").notNull().default(false),
  collection: varchar("collection", { length: 80 }).notNull(),
  images: jsonb("images").$type<string[]>().notNull().default([]),
  features: jsonb("features").$type<string[]>().notNull().default([]),
  deliverables: jsonb("deliverables").$type<string[]>().notNull().default([]),
  platforms: jsonb("platforms").$type<string[]>().notNull().default([]),
  rating: integer("rating").notNull().default(50), // *10, e.g. 48 = 4.8
  reviewCount: integer("review_count").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const reviews = pgTable("reviews", {
  id: serial("id").primaryKey(),
  productId: integer("product_id")
    .notNull()
    .references(() => products.id, { onDelete: "cascade" }),
  author: text("author").notNull(),
  handle: text("handle").notNull(),
  avatar: text("avatar"),
  rating: integer("rating").notNull(), // 1-5
  title: text("title").notNull(),
  body: text("body").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  reference: varchar("reference", { length: 40 }).notNull().unique(),
  email: text("email").notNull(),
  fullName: text("full_name").notNull(),
  company: text("company"),
  items: jsonb("items")
    .$type<
      { productId: number; name: string; price: number; quantity: number }[]
    >()
    .notNull()
    .default([]),
  subtotal: integer("subtotal").notNull(),
  discount: integer("discount").notNull().default(0),
  total: integer("total").notNull(),
  paymentMethod: varchar("payment_method", { length: 20 })
    .notNull()
    .default("card"),
  payerEmail: text("payer_email"),
  status: varchar("status", { length: 20 }).notNull().default("paid"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const contactMessages = pgTable("contact_messages", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  topic: varchar("topic", { length: 40 }).notNull().default("support"),
  message: text("message").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export type Product = typeof products.$inferSelect;
export type Review = typeof reviews.$inferSelect;
export type Order = typeof orders.$inferSelect;
export type ContactMessage = typeof contactMessages.$inferSelect;
