export type ProductDTO = {
  id: number;
  slug: string;
  name: string;
  tagline: string;
  description: string;
  category: string;
  billing: string;
  price: number;
  compareAtPrice: number | null;
  featured: boolean;
  collection: string;
  images: string[];
  features: string[];
  deliverables: string[];
  platforms: string[];
  rating: number;
  reviewCount: number;
};

export type ReviewDTO = {
  id: number;
  productId: number;
  author: string;
  handle: string;
  avatar: string | null;
  rating: number;
  title: string;
  body: string;
  createdAt: string;
};

export type CartItem = {
  productId: number;
  slug: string;
  name: string;
  price: number;
  billing: string;
  image: string;
  quantity: number;
};
