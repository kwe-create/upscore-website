export const SITE = {
  name: "UPSCORE",
  contactPhone: "0797533743",
  contactPhoneHref: "tel:+254797533743",
  paypalEmail: "kbett8917@gmail.com",
  supportEmail: "feliciarhodes@gmail.com",
} as const;
