export type SeedProduct = {
  slug: string;
  name: string;
  tagline: string;
  description: string;
  category: string;
  billing: string;
  price: number;
  compareAtPrice: number | null;
  featured: boolean;
  collection: string;
  images: string[];
  features: string[];
  deliverables: string[];
  platforms: string[];
  rating: number;
  reviewCount: number;
};

export type SeedReview = {
  productSlug: string;
  author: string;
  handle: string;
  rating: number;
  title: string;
  body: string;
};

const IMG = {
  hero: "/images/hero.jpg",
  growth: "/images/growth.jpg",
  content: "/images/content.jpg",
  strategy: "/images/strategy.jpg",
  video: "/images/video.jpg",
  branding: "/images/branding.jpg",
  community: "/images/community.jpg",
  ads: "/images/ads.jpg",
};

export const seedProducts: SeedProduct[] = [
  {
    slug: "creator-launchpad",
    name: "Creator Launchpad",
    tagline: "Everything you need to go from zero to a real audience.",
    description:
      "The Launchpad is our all-in-one starter plan for creators who are serious about building. We take content off your plate — planning, scheduling, engagement, and reporting — so you can focus on making things people love. You bring the raw ideas; we turn them into a consistent, on-brand presence that compounds week after week.",
    category: "Full Service",
    billing: "monthly",
    price: 29900,
    compareAtPrice: 39900,
    featured: true,
    collection: "Growth",
    images: [IMG.hero, IMG.growth, IMG.community],
    features: [
      "12 fully-managed posts / month",
      "Daily community engagement (1hr/day)",
      "Content calendar + scheduling",
      "Monthly growth report",
      "Dedicated account manager",
    ],
    deliverables: [
      "3 platform profiles optimized",
      "Weekly content batches",
      "Hashtag & trend research",
      "Monthly 1:1 strategy call",
    ],
    platforms: ["Instagram", "TikTok", "YouTube"],
    rating: 49,
    reviewCount: 3,
  },
  {
    slug: "viral-reels-engine",
    name: "Viral Reels Engine",
    tagline: "Short-form video edited to stop the scroll.",
    description:
      "Reels and TikToks are the fastest way to reach new audiences — but editing eats your entire week. Our Reels Engine turns your raw footage into scroll-stopping short-form video with punchy captions, trending audio, and retention-optimized pacing. Send us the clips, get back finished videos ready to post.",
    category: "Video",
    billing: "monthly",
    price: 44900,
    compareAtPrice: null,
    featured: true,
    collection: "Content",
    images: [IMG.video, IMG.content, IMG.community],
    features: [
      "16 edited short-form videos / month",
      "Trend & audio matching",
      "Captions, hooks & B-roll",
      "48-hour turnaround",
      "Unlimited minor revisions",
    ],
    deliverables: [
      "Vertical 9:16 exports",
      "Thumbnail frames",
      "Posting-ready captions",
      "Performance tracking sheet",
    ],
    platforms: ["Instagram", "TikTok", "YouTube"],
    rating: 50,
    reviewCount: 3,
  },
  {
    slug: "signature-brand-kit",
    name: "Signature Brand Kit",
    tagline: "A cohesive visual identity that feels unmistakably you.",
    description:
      "Your content deserves a look that's instantly recognizable. The Signature Brand Kit gives you a complete visual system — color palette, typography, templates, and guidelines — so every post, story, and thumbnail feels like it belongs to the same premium brand. Delivered once, used forever.",
    category: "Branding",
    billing: "one-time",
    price: 89900,
    compareAtPrice: 119900,
    featured: true,
    collection: "Strategy",
    images: [IMG.branding, IMG.strategy, IMG.content],
    features: [
      "Custom color & type system",
      "20 editable post templates",
      "Story & highlight covers",
      "Logo & wordmark refresh",
      "Brand guidelines PDF",
    ],
    deliverables: [
      "Canva & Figma template pack",
      "Highlight cover set",
      "Font & color tokens",
      "2 rounds of revisions",
    ],
    platforms: ["Instagram", "TikTok", "YouTube", "LinkedIn"],
    rating: 48,
    reviewCount: 2,
  },
  {
    slug: "growth-accelerator",
    name: "Growth Accelerator",
    tagline: "Aggressive, data-driven growth for creators ready to scale.",
    description:
      "For creators who've found their footing and want to pour fuel on the fire. The Accelerator combines high-volume content, paid amplification strategy, and weekly optimization sprints. We treat your channel like a growth product — testing hooks, formats, and posting cadence until the numbers move.",
    category: "Full Service",
    billing: "monthly",
    price: 79900,
    compareAtPrice: null,
    featured: true,
    collection: "Growth",
    images: [IMG.growth, IMG.ads, IMG.hero],
    features: [
      "24 managed posts / month",
      "Weekly optimization sprints",
      "Paid boost strategy included",
      "A/B tested hooks & thumbnails",
      "Bi-weekly strategy calls",
    ],
    deliverables: [
      "Cross-platform content plan",
      "Analytics dashboard access",
      "Competitor teardown",
      "Priority support",
    ],
    platforms: ["Instagram", "TikTok", "YouTube", "LinkedIn"],
    rating: 49,
    reviewCount: 2,
  },
  {
    slug: "community-concierge",
    name: "Community Concierge",
    tagline: "Real conversations that turn followers into superfans.",
    description:
      "Engagement is where loyalty is built — and where creators burn out fastest. Our Community Concierge handles your DMs, comments, and mentions in your voice, every single day. We flag opportunities, nurture your top fans, and keep your community feeling seen while you stay in flow.",
    category: "Engagement",
    billing: "monthly",
    price: 34900,
    compareAtPrice: 44900,
    featured: false,
    collection: "Growth",
    images: [IMG.community, IMG.hero, IMG.growth],
    features: [
      "Daily comment & DM management",
      "Superfan identification",
      "Voice & tone matching",
      "Weekly sentiment recap",
      "Crisis & moderation support",
    ],
    deliverables: [
      "Response playbook",
      "Fan CRM setup",
      "Weekly engagement report",
    ],
    platforms: ["Instagram", "TikTok", "YouTube"],
    rating: 47,
    reviewCount: 2,
  },
  {
    slug: "content-calendar-pro",
    name: "Content Calendar Pro",
    tagline: "30 days of planned content, mapped to your goals.",
    description:
      "Never stare at a blank calendar again. Content Calendar Pro delivers a fully-planned month of content ideas, hooks, and formats tailored to your niche and goals. Each idea comes with a hook, a caption starter, and a format recommendation so you can batch-create with total clarity.",
    category: "Strategy",
    billing: "monthly",
    price: 14900,
    compareAtPrice: null,
    featured: false,
    collection: "Strategy",
    images: [IMG.strategy, IMG.content, IMG.branding],
    features: [
      "30 content ideas / month",
      "Hooks & caption starters",
      "Format recommendations",
      "Trend integration",
      "Notion calendar delivery",
    ],
    deliverables: [
      "Editable Notion board",
      "Monthly theme planning",
      "Hook swipe file",
    ],
    platforms: ["Instagram", "TikTok", "YouTube", "LinkedIn"],
    rating: 48,
    reviewCount: 2,
  },
  {
    slug: "paid-ads-amplifier",
    name: "Paid Ads Amplifier",
    tagline: "Turn your best content into a reach machine.",
    description:
      "You've made content that resonates — now let's put budget behind it. The Ads Amplifier plans, launches, and optimizes paid campaigns across Meta and TikTok to extend the reach of your top-performing posts. We handle targeting, creative variations, and daily optimization to keep your cost-per-follow low.",
    category: "Paid Media",
    billing: "monthly",
    price: 59900,
    compareAtPrice: null,
    featured: false,
    collection: "Growth",
    images: [IMG.ads, IMG.growth, IMG.community],
    features: [
      "Full campaign management",
      "Creative variation testing",
      "Daily budget optimization",
      "Audience research & targeting",
      "Weekly performance reports",
    ],
    deliverables: [
      "Campaign setup & pixel",
      "3 creative variations / campaign",
      "ROAS dashboard",
    ],
    platforms: ["Instagram", "TikTok"],
    rating: 47,
    reviewCount: 1,
  },
  {
    slug: "thumbnail-lab",
    name: "Thumbnail Lab",
    tagline: "Click-worthy thumbnails engineered for CTR.",
    description:
      "The thumbnail decides whether your video gets watched. Thumbnail Lab designs high-contrast, curiosity-driven thumbnails backed by CTR best practices. Send us your title and footage — we deliver multiple thumbnail concepts you can A/B test, plus the editable files.",
    category: "Design",
    billing: "package",
    price: 19900,
    compareAtPrice: 24900,
    featured: false,
    collection: "Content",
    images: [IMG.content, IMG.branding, IMG.video],
    features: [
      "10 custom thumbnails / pack",
      "2 concepts per video",
      "CTR-optimized layouts",
      "Editable source files",
      "24-hour rush available",
    ],
    deliverables: [
      "PNG + PSD exports",
      "A/B variant set",
      "Title copy suggestions",
    ],
    platforms: ["YouTube", "Instagram"],
    rating: 49,
    reviewCount: 1,
  },
  {
    slug: "podcast-repurpose-suite",
    name: "Podcast Repurpose Suite",
    tagline: "One episode. Twenty pieces of content.",
    description:
      "Your long-form content is a goldmine. The Repurpose Suite takes each podcast or long video and turns it into a full week of short clips, audiograms, quote graphics, and captions. Maximize every minute you record and stay omnipresent without recording more.",
    category: "Video",
    billing: "monthly",
    price: 54900,
    compareAtPrice: null,
    featured: false,
    collection: "Content",
    images: [IMG.video, IMG.content, IMG.strategy],
    features: [
      "4 episodes repurposed / month",
      "20+ clips per month",
      "Audiograms & quote cards",
      "Show notes & captions",
      "SEO-friendly descriptions",
    ],
    deliverables: [
      "Short clips (9:16 & 1:1)",
      "Quote graphic set",
      "Episode show notes",
    ],
    platforms: ["Instagram", "TikTok", "YouTube", "LinkedIn"],
    rating: 48,
    reviewCount: 1,
  },
];

export const seedReviews: SeedReview[] = [
  {
    productSlug: "creator-launchpad",
    author: "Maya Ellison",
    handle: "@mayamakes",
    rating: 5,
    title: "Went from 8k to 41k in four months",
    body: "I was drowning trying to do it all myself. The Launchpad team took over my calendar and engagement and my growth completely changed trajectory. The monthly reports actually make sense of the numbers.",
  },
  {
    productSlug: "creator-launchpad",
    author: "Dev Patel",
    handle: "@devbuilds",
    rating: 5,
    title: "Feels like having a real team",
    body: "My account manager gets my voice better than I do some days. Posting is consistent for the first time ever and I finally have my evenings back.",
  },
  {
    productSlug: "creator-launchpad",
    author: "Sofia Reyes",
    handle: "@sofiacreates",
    rating: 4,
    title: "Great value, ramp took a minute",
    body: "First two weeks were onboarding-heavy but once they nailed my style it's been smooth. Engagement on my posts doubled.",
  },
  {
    productSlug: "viral-reels-engine",
    author: "Jordan Kim",
    handle: "@jordanonfilm",
    rating: 5,
    title: "Three reels hit over a million",
    body: "The editing quality is unreal. They understand pacing and hooks in a way no freelancer I hired ever did. 48-hour turnaround is legit.",
  },
  {
    productSlug: "viral-reels-engine",
    author: "Priya Nair",
    handle: "@priyawellness",
    rating: 5,
    title: "My most-saved content ever",
    body: "I just dump my raw clips in a folder and get back polished reels that sound like me. The trend matching keeps me relevant without the doomscrolling.",
  },
  {
    productSlug: "viral-reels-engine",
    author: "Marcus Cole",
    handle: "@marcuscooks",
    rating: 5,
    title: "Worth every dollar",
    body: "Food content lives or dies on the edit. These are the best cuts my recipes have ever had. Booked out with brand deals now.",
  },
  {
    productSlug: "signature-brand-kit",
    author: "Elena Voss",
    handle: "@elenastudio",
    rating: 5,
    title: "My feed finally looks intentional",
    body: "The template pack alone paid for itself. Everything looks cohesive and premium now, and I can create on-brand posts in minutes.",
  },
  {
    productSlug: "signature-brand-kit",
    author: "Tom Rivera",
    handle: "@tomtravels",
    rating: 4,
    title: "Beautiful system",
    body: "Loved the color and type work. Would've liked a couple more template variations but the guidelines PDF is fantastic.",
  },
  {
    productSlug: "growth-accelerator",
    author: "Aisha Bello",
    handle: "@aishaspeaks",
    rating: 5,
    title: "Serious results for serious creators",
    body: "The weekly optimization sprints are addictive. We test everything and the channel just keeps climbing. Bi-weekly calls keep me accountable.",
  },
  {
    productSlug: "growth-accelerator",
    author: "Liam Fischer",
    handle: "@liamfitness",
    rating: 5,
    title: "The paid strategy is a cheat code",
    body: "Combining organic and boosted content the way they do got my cost-per-follow down to pennies. Scaled past 100k this quarter.",
  },
  {
    productSlug: "community-concierge",
    author: "Nadia Haddad",
    handle: "@nadiapaints",
    rating: 5,
    title: "My DMs are finally under control",
    body: "They respond in my voice so well nobody can tell. My top fans feel taken care of and I'm not glued to my phone anymore.",
  },
  {
    productSlug: "community-concierge",
    author: "Chris Obi",
    handle: "@chrisplays",
    rating: 4,
    title: "Big weight off my shoulders",
    body: "Comment moderation during launches used to stress me out. Now it's handled. Weekly sentiment recap is a nice touch.",
  },
  {
    productSlug: "content-calendar-pro",
    author: "Hana Suzuki",
    handle: "@hanadesigns",
    rating: 5,
    title: "Never blank-page paralyzed again",
    body: "Thirty ideas with hooks and formats every month. I batch a whole month in one afternoon now. Best $149 I spend.",
  },
  {
    productSlug: "content-calendar-pro",
    author: "Owen Blake",
    handle: "@owenfinance",
    rating: 4,
    title: "Solid framework",
    body: "The hooks are genuinely good and the Notion board is clean. Occasionally an idea misses my niche but easy to swap.",
  },
  {
    productSlug: "paid-ads-amplifier",
    author: "Zara Quinn",
    handle: "@zarabeauty",
    rating: 5,
    title: "Reach exploded",
    body: "They took my best post and turned it into a follower magnet. The ROAS dashboard makes it obvious it's working.",
  },
  {
    productSlug: "thumbnail-lab",
    author: "Ben Carter",
    handle: "@bencartertech",
    rating: 5,
    title: "CTR up 40%",
    body: "The A/B variants let me actually test what works. My channel's average view duration jumped once the clicks improved.",
  },
  {
    productSlug: "podcast-repurpose-suite",
    author: "Lucia Moreno",
    handle: "@luciatalks",
    rating: 5,
    title: "One recording, everywhere",
    body: "I record once and suddenly I'm all over every platform. The audiograms and quote cards look premium. Total time-saver.",
  },
];
