import { db } from "@/db";
import { products, reviews } from "@/db/schema";
import { eq, desc, asc, and, gte, lte, SQL, sql } from "drizzle-orm";
import type { ProductDTO, ReviewDTO } from "./types";

function toProductDTO(p: typeof products.$inferSelect): ProductDTO {
  return {
    id: p.id,
    slug: p.slug,
    name: p.name,
    tagline: p.tagline,
    description: p.description,
    category: p.category,
    billing: p.billing,
    price: p.price,
    compareAtPrice: p.compareAtPrice,
    featured: p.featured,
    collection: p.collection,
    images: p.images,
    features: p.features,
    deliverables: p.deliverables,
    platforms: p.platforms,
    rating: p.rating,
    reviewCount: p.reviewCount,
  };
}

export async function getAllProducts(): Promise<ProductDTO[]> {
  const rows = await db.select().from(products).orderBy(asc(products.id));
  return rows.map(toProductDTO);
}

export async function getFeaturedProducts(): Promise<ProductDTO[]> {
  const rows = await db
    .select()
    .from(products)
    .where(eq(products.featured, true))
    .orderBy(asc(products.id));
  return rows.map(toProductDTO);
}

export async function getProductBySlug(
  slug: string,
): Promise<ProductDTO | null> {
  const rows = await db
    .select()
    .from(products)
    .where(eq(products.slug, slug))
    .limit(1);
  return rows[0] ? toProductDTO(rows[0]) : null;
}

export async function getRelatedProducts(
  collection: string,
  excludeId: number,
): Promise<ProductDTO[]> {
  const rows = await db
    .select()
    .from(products)
    .where(eq(products.collection, collection))
    .limit(4);
  return rows.map(toProductDTO).filter((p) => p.id !== excludeId).slice(0, 3);
}

export async function getReviewsForProduct(
  productId: number,
): Promise<ReviewDTO[]> {
  const rows = await db
    .select()
    .from(reviews)
    .where(eq(reviews.productId, productId))
    .orderBy(desc(reviews.createdAt));
  return rows.map((r) => ({
    id: r.id,
    productId: r.productId,
    author: r.author,
    handle: r.handle,
    avatar: r.avatar,
    rating: r.rating,
    title: r.title,
    body: r.body,
    createdAt: r.createdAt.toISOString(),
  }));
}

export type FilterOptions = {
  collections: string[];
  platforms: string[];
  billing: string[];
  minPrice: number;
  maxPrice: number;
  sort: string;
};

export async function getFilteredProducts(
  opts: Partial<FilterOptions>,
): Promise<ProductDTO[]> {
  const conditions: SQL[] = [];

  if (opts.collections && opts.collections.length) {
    conditions.push(
      sql`${products.collection} = ANY(${opts.collections})`,
    );
  }
  if (opts.billing && opts.billing.length) {
    conditions.push(sql`${products.billing} = ANY(${opts.billing})`);
  }
  if (typeof opts.minPrice === "number") {
    conditions.push(gte(products.price, opts.minPrice));
  }
  if (typeof opts.maxPrice === "number") {
    conditions.push(lte(products.price, opts.maxPrice));
  }

  let order;
  switch (opts.sort) {
    case "price-asc":
      order = asc(products.price);
      break;
    case "price-desc":
      order = desc(products.price);
      break;
    case "rating":
      order = desc(products.rating);
      break;
    case "popular":
      order = desc(products.reviewCount);
      break;
    default:
      order = asc(products.id);
  }

  const base = db.select().from(products);
  const rows = conditions.length
    ? await base.where(and(...conditions)).orderBy(order)
    : await base.orderBy(order);

  let result = rows.map(toProductDTO);

  if (opts.platforms && opts.platforms.length) {
    result = result.filter((p) =>
      opts.platforms!.some((pl) => p.platforms.includes(pl)),
    );
  }

  return result;
}
