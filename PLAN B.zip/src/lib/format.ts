export function formatPrice(cents: number): string {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: cents % 100 === 0 ? 0 : 2,
  }).format(cents / 100);
}

export function billingLabel(billing: string): string {
  switch (billing) {
    case "monthly":
      return "/mo";
    case "one-time":
      return "one-time";
    case "package":
      return "/project";
    default:
      return "";
  }
}
