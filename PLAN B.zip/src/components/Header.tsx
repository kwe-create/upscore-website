"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { useCart } from "./CartProvider";
import { CartIcon, MenuIcon, CloseIcon } from "./Icons";

const nav = [
  { href: "/shop", label: "Shop All" },
  { href: "/shop?collection=Growth", label: "Growth" },
  { href: "/shop?collection=Content", label: "Content" },
  { href: "/shop?collection=Strategy", label: "Strategy" },
  { href: "/#contact", label: "Contact" },
];

export function Header() {
  const { count, openCart, hydrated } = useCart();
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`sticky top-0 z-40 transition-all duration-300 ${
        scrolled
          ? "bg-cream/85 backdrop-blur-xl border-b border-sand shadow-sm"
          : "bg-transparent border-b border-transparent"
      }`}
    >
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <div className="flex h-16 sm:h-20 items-center justify-between">
          <div className="flex items-center gap-8">
            <Link href="/" className="group flex items-center gap-2">
              <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-ink text-cream font-display text-lg font-bold transition-transform group-hover:rotate-12">
                U
              </span>
              <span className="font-display text-xl font-semibold tracking-tight">
                UPSCORE
              </span>
            </Link>
            <nav className="hidden lg:flex items-center gap-6">
              {nav.map((item) => (
                <Link
                  key={item.label}
                  href={item.href}
                  className="text-sm font-medium text-ink/70 hover:text-ink transition-colors relative after:absolute after:-bottom-1 after:left-0 after:h-px after:w-0 after:bg-coral hover:after:w-full after:transition-all"
                >
                  {item.label}
                </Link>
              ))}
            </nav>
          </div>

          <div className="flex items-center gap-2 sm:gap-4">
            <Link
              href="/shop"
              className="hidden sm:inline-flex text-sm font-medium text-ink/70 hover:text-ink transition-colors"
            >
              Browse plans
            </Link>
            <button
              onClick={openCart}
              aria-label="Open cart"
              className="relative flex h-10 w-10 items-center justify-center rounded-full hover:bg-sand transition-colors"
            >
              <CartIcon className="w-5 h-5" />
              {hydrated && count > 0 && (
                <span className="absolute -top-0.5 -right-0.5 flex h-5 w-5 items-center justify-center rounded-full bg-coral text-[10px] font-bold text-white animate-fade-in">
                  {count}
                </span>
              )}
            </button>
            <button
              onClick={() => setMobileOpen((o) => !o)}
              aria-label="Menu"
              className="lg:hidden flex h-10 w-10 items-center justify-center rounded-full hover:bg-sand transition-colors"
            >
              {mobileOpen ? <CloseIcon className="w-5 h-5" /> : <MenuIcon className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {mobileOpen && (
        <div className="lg:hidden border-t border-sand bg-cream/95 backdrop-blur-xl animate-fade-in">
          <nav className="flex flex-col px-5 py-3">
            {nav.map((item) => (
              <Link
                key={item.label}
                href={item.href}
                onClick={() => setMobileOpen(false)}
                className="py-3 text-base font-medium border-b border-sand/60 last:border-0"
              >
                {item.label}
              </Link>
            ))}
          </nav>
        </div>
      )}
    </header>
  );
}
