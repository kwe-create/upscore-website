"use client";

import Link from "next/link";
import Image from "next/image";
import type { ProductDTO } from "@/lib/types";
import { formatPrice, billingLabel } from "@/lib/format";
import { Stars, PlusIcon } from "./Icons";
import { useCart } from "./CartProvider";

export function ProductCard({
  product,
  index = 0,
}: {
  product: ProductDTO;
  index?: number;
}) {
  const { addItem } = useCart();

  const onAdd = (e: React.MouseEvent) => {
    e.preventDefault();
    addItem({
      productId: product.id,
      slug: product.slug,
      name: product.name,
      price: product.price,
      billing: product.billing,
      image: product.images[0],
    });
  };

  return (
    <Link
      href={`/product/${product.slug}`}
      className="group flex flex-col hover-lift animate-fade-up"
      style={{ animationDelay: `${Math.min(index, 8) * 60}ms` }}
    >
      <div className="relative aspect-[4/5] overflow-hidden rounded-2xl bg-sand">
        <Image
          src={product.images[0]}
          alt={product.name}
          fill
          sizes="(max-width: 768px) 50vw, 25vw"
          className="object-cover transition-transform duration-700 group-hover:scale-105"
        />
        <div className="absolute inset-x-0 top-0 flex items-start justify-between p-3">
          <div className="flex flex-col gap-1.5">
            {product.compareAtPrice && (
              <span className="rounded-full bg-coral px-2.5 py-1 text-[11px] font-bold uppercase tracking-wide text-white shadow-sm">
                Save {formatPrice(product.compareAtPrice - product.price)}
              </span>
            )}
            {product.featured && (
              <span className="rounded-full bg-ink/85 px-2.5 py-1 text-[11px] font-semibold uppercase tracking-wide text-cream backdrop-blur">
                Bestseller
              </span>
            )}
          </div>
        </div>
        <button
          onClick={onAdd}
          aria-label={`Add ${product.name} to cart`}
          className="absolute bottom-3 right-3 flex h-11 w-11 translate-y-2 items-center justify-center rounded-full bg-cream text-ink opacity-0 shadow-lg transition-all duration-300 group-hover:translate-y-0 group-hover:opacity-100 hover:bg-coral hover:text-white"
        >
          <PlusIcon className="w-5 h-5" />
        </button>
      </div>

      <div className="mt-4 flex flex-col gap-1">
        <div className="flex items-center gap-2">
          <span className="text-[11px] font-semibold uppercase tracking-wider text-plum">
            {product.category}
          </span>
          <span className="text-ink/20">·</span>
          <Stars rating={product.rating / 10} />
        </div>
        <h3 className="font-display text-lg font-semibold leading-snug group-hover:text-coral transition-colors">
          {product.name}
        </h3>
        <p className="text-sm text-ink/55 line-clamp-2">{product.tagline}</p>
        <div className="mt-1 flex items-baseline gap-2">
          <span className="font-display text-lg font-semibold">
            {formatPrice(product.price)}
          </span>
          <span className="text-xs text-ink/45">
            {billingLabel(product.billing)}
          </span>
          {product.compareAtPrice && (
            <span className="text-xs text-ink/35 line-through">
              {formatPrice(product.compareAtPrice)}
            </span>
          )}
        </div>
      </div>
    </Link>
  );
}
