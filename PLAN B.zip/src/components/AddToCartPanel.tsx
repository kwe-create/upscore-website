"use client";

import { useState } from "react";
import type { ProductDTO } from "@/lib/types";
import { useCart } from "./CartProvider";
import { formatPrice, billingLabel } from "@/lib/format";
import { MinusIcon, PlusIcon, CheckIcon } from "./Icons";

export function AddToCartPanel({ product }: { product: ProductDTO }) {
  const { addItem } = useCart();
  const [qty, setQty] = useState(1);
  const [added, setAdded] = useState(false);

  const handleAdd = () => {
    addItem(
      {
        productId: product.id,
        slug: product.slug,
        name: product.name,
        price: product.price,
        billing: product.billing,
        image: product.images[0],
      },
      qty,
    );
    setAdded(true);
    setTimeout(() => setAdded(false), 1800);
  };

  return (
    <div className="mt-6 rounded-2xl border border-sand bg-cream p-5">
      <div className="flex items-baseline gap-3">
        <span className="font-display text-3xl font-semibold">
          {formatPrice(product.price)}
        </span>
        <span className="text-sm text-ink/50">
          {billingLabel(product.billing)}
        </span>
        {product.compareAtPrice && (
          <span className="text-sm text-ink/40 line-through">
            {formatPrice(product.compareAtPrice)}
          </span>
        )}
      </div>

      <div className="mt-5 flex items-center gap-4">
        <div className="flex items-center rounded-full border border-ink/15">
          <button
            onClick={() => setQty((q) => Math.max(1, q - 1))}
            className="flex h-11 w-11 items-center justify-center rounded-full hover:bg-sand transition-colors"
            aria-label="Decrease quantity"
          >
            <MinusIcon className="w-4 h-4" />
          </button>
          <span className="w-10 text-center font-semibold">{qty}</span>
          <button
            onClick={() => setQty((q) => q + 1)}
            className="flex h-11 w-11 items-center justify-center rounded-full hover:bg-sand transition-colors"
            aria-label="Increase quantity"
          >
            <PlusIcon className="w-4 h-4" />
          </button>
        </div>
        <button
          onClick={handleAdd}
          className={`flex flex-1 items-center justify-center gap-2 rounded-full px-6 py-3.5 text-sm font-semibold text-white transition-all ${
            added ? "bg-plum" : "bg-coral hover:bg-coral/90"
          }`}
        >
          {added ? (
            <>
              <CheckIcon className="w-4 h-4" /> Added to cart
            </>
          ) : (
            <>Add to cart · {formatPrice(product.price * qty)}</>
          )}
        </button>
      </div>

      <div className="mt-4 flex flex-wrap gap-x-5 gap-y-2 text-xs text-ink/55">
        <span className="flex items-center gap-1.5">
          <CheckIcon className="w-3.5 h-3.5 text-coral" /> Cancel anytime
        </span>
        <span className="flex items-center gap-1.5">
          <CheckIcon className="w-3.5 h-3.5 text-coral" /> 48h onboarding
        </span>
        <span className="flex items-center gap-1.5">
          <CheckIcon className="w-3.5 h-3.5 text-coral" /> Dedicated manager
        </span>
      </div>
    </div>
  );
}
