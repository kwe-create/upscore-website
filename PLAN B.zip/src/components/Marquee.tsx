export function Marquee() {
  const items = [
    "12,000+ posts published",
    "★ 4.9 average rating",
    "48-hour turnaround",
    "Trusted by 1,400+ creators",
    "3.2B impressions driven",
    "Cancel anytime",
  ];
  const doubled = [...items, ...items];
  return (
    <div className="overflow-hidden border-y border-ink/10 bg-ink py-4 text-cream">
      <div className="flex w-max animate-marquee gap-10 whitespace-nowrap">
        {doubled.map((item, i) => (
          <span
            key={i}
            className="flex items-center gap-10 text-sm font-medium tracking-wide"
          >
            {item}
            <span className="text-coral">◆</span>
          </span>
        ))}
      </div>
    </div>
  );
}
