import Link from "next/link";
import { SITE } from "@/lib/site";

export function Footer() {
  return (
    <footer className="border-t border-sand bg-ink text-cream mt-24">
      <div className="mx-auto max-w-7xl px-5 sm:px-8 py-16">
        <div className="grid gap-12 md:grid-cols-4">
          <div className="md:col-span-1">
            <div className="flex items-center gap-2">
              <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-cream text-ink font-display text-lg font-bold">
                U
              </span>
              <span className="font-display text-xl font-semibold">UPSCORE</span>
            </div>
            <p className="mt-4 text-sm text-cream/60 leading-relaxed">
              Social media management crafted for content creators who refuse to
              settle for average.
            </p>
          </div>

          <div>
            <h4 className="text-sm font-semibold uppercase tracking-wider text-cream/50">
              Shop
            </h4>
            <ul className="mt-4 space-y-3 text-sm text-cream/80">
              <li><Link href="/shop" className="hover:text-coral transition-colors">All Plans</Link></li>
              <li><Link href="/shop?collection=Growth" className="hover:text-coral transition-colors">Growth</Link></li>
              <li><Link href="/shop?collection=Content" className="hover:text-coral transition-colors">Content</Link></li>
              <li><Link href="/shop?collection=Strategy" className="hover:text-coral transition-colors">Strategy</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="text-sm font-semibold uppercase tracking-wider text-cream/50">
              Get in touch
            </h4>
            <ul className="mt-4 space-y-3 text-sm text-cream/80">
              <li className="flex flex-col">
                <span className="text-xs uppercase tracking-wider text-cream/40">
                  Contact
                </span>
                <a
                  href={SITE.contactPhoneHref}
                  className="font-medium hover:text-coral transition-colors"
                >
                  {SITE.contactPhone}
                </a>
              </li>
              <li className="flex flex-col">
                <span className="text-xs uppercase tracking-wider text-cream/40">
                  Payment via PayPal
                </span>
                <a
                  href={`https://www.paypal.com/paypalme/${SITE.paypalEmail}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="font-medium break-all hover:text-coral transition-colors"
                >
                  {SITE.paypalEmail}
                </a>
              </li>
              <li className="flex flex-col">
                <span className="text-xs uppercase tracking-wider text-cream/40">
                  Support
                </span>
                <a
                  href={`mailto:${SITE.supportEmail}`}
                  className="font-medium break-all hover:text-coral transition-colors"
                >
                  {SITE.supportEmail}
                </a>
              </li>
              <li className="pt-1">
                <Link
                  href="/#contact"
                  className="inline-flex items-center gap-1 text-coral font-semibold hover:underline"
                >
                  Message us →
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-sm font-semibold uppercase tracking-wider text-cream/50">
              Get the drop
            </h4>
            <p className="mt-4 text-sm text-cream/60">
              Growth tips & new plans, twice a month.
            </p>
            <form className="mt-4 flex gap-2">
              <input
                type="email"
                placeholder="you@creator.com"
                className="min-w-0 flex-1 rounded-full bg-cream/10 border border-cream/20 px-4 py-2.5 text-sm text-cream placeholder:text-cream/40 focus:outline-none focus:border-coral"
              />
              <button
                type="button"
                className="rounded-full bg-coral px-4 py-2.5 text-sm font-semibold text-white hover:bg-coral/90 transition-colors"
              >
                Join
              </button>
            </form>
          </div>
        </div>

        <div className="mt-14 flex flex-col sm:flex-row items-center justify-between gap-4 border-t border-cream/10 pt-8 text-sm text-cream/50">
          <p>© {new Date().getFullYear()} UPSCORE Studio. All rights reserved.</p>
          <div className="flex gap-6">
            <span className="cursor-pointer hover:text-cream">Privacy</span>
            <span className="cursor-pointer hover:text-cream">Terms</span>
            <span className="cursor-pointer hover:text-cream">Instagram</span>
            <span className="cursor-pointer hover:text-cream">TikTok</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
