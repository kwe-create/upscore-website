"use client";

import { useState } from "react";
import { SITE } from "@/lib/site";
import { CheckIcon } from "./Icons";

const TOPICS = [
  { value: "support", label: "Support" },
  { value: "sales", label: "Sales" },
  { value: "billing", label: "Billing" },
  { value: "general", label: "General" },
];

export function ContactSection() {
  const [form, setForm] = useState({
    name: "",
    email: "",
    topic: "support",
    message: "",
  });
  const [status, setStatus] = useState<"idle" | "sending" | "sent">("idle");
  const [error, setError] = useState("");

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    if (!form.name || !form.email || !form.message) {
      setError("Please fill in your name, email, and message.");
      return;
    }
    setStatus("sending");
    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (data.ok) {
        setStatus("sent");
        setForm({ name: "", email: "", topic: "support", message: "" });
      } else {
        setStatus("idle");
        setError(data.error || "Something went wrong.");
      }
    } catch {
      setStatus("idle");
      setError("Network error. Please try again.");
    }
  };

  return (
    <section
      id="contact"
      className="scroll-mt-24 bg-blush/40 border-y border-sand"
    >
      <div className="mx-auto max-w-7xl px-5 sm:px-8 py-20">
        <div className="grid gap-12 lg:grid-cols-2 lg:items-start">
          {/* Info */}
          <div>
            <span className="text-xs font-semibold uppercase tracking-wider text-plum">
              Talk to us
            </span>
            <h2 className="mt-2 font-display text-4xl font-semibold tracking-tight sm:text-5xl">
              Questions? We&apos;re here.
            </h2>
            <p className="mt-4 max-w-md text-ink/60">
              Reach out about a plan, your account, or a custom package. Real
              humans, quick replies.
            </p>

            <div className="mt-8 space-y-4">
              <a
                href={SITE.contactPhoneHref}
                className="group flex items-center gap-4 rounded-2xl border border-sand bg-cream p-5 transition-colors hover:border-coral"
              >
                <span className="flex h-11 w-11 items-center justify-center rounded-full bg-coral/15 text-lg">
                  📞
                </span>
                <span>
                  <span className="block text-xs uppercase tracking-wider text-ink/45">
                    Contact
                  </span>
                  <span className="block font-semibold group-hover:text-coral transition-colors">
                    {SITE.contactPhone}
                  </span>
                </span>
              </a>

              <a
                href={`https://www.paypal.com/paypalme/${SITE.paypalEmail}`}
                target="_blank"
                rel="noopener noreferrer"
                className="group flex items-center gap-4 rounded-2xl border border-sand bg-cream p-5 transition-colors hover:border-coral"
              >
                <span className="flex h-11 w-11 items-center justify-center rounded-full bg-plum/15 text-lg">
                  💳
                </span>
                <span>
                  <span className="block text-xs uppercase tracking-wider text-ink/45">
                    Payment via PayPal
                  </span>
                  <span className="block font-semibold break-all group-hover:text-coral transition-colors">
                    {SITE.paypalEmail}
                  </span>
                </span>
              </a>

              <a
                href={`mailto:${SITE.supportEmail}`}
                className="group flex items-center gap-4 rounded-2xl border border-sand bg-cream p-5 transition-colors hover:border-coral"
              >
                <span className="flex h-11 w-11 items-center justify-center rounded-full bg-coral/15 text-lg">
                  ✉️
                </span>
                <span>
                  <span className="block text-xs uppercase tracking-wider text-ink/45">
                    Support
                  </span>
                  <span className="block font-semibold break-all group-hover:text-coral transition-colors">
                    {SITE.supportEmail}
                  </span>
                </span>
              </a>
            </div>
          </div>

          {/* Form */}
          <div className="rounded-3xl border border-sand bg-cream p-6 sm:p-8">
            {status === "sent" ? (
              <div className="flex flex-col items-center justify-center py-16 text-center">
                <span className="flex h-16 w-16 items-center justify-center rounded-full bg-coral/15 text-coral">
                  <CheckIcon className="w-8 h-8" />
                </span>
                <h3 className="mt-5 font-display text-2xl font-semibold">
                  Message sent!
                </h3>
                <p className="mt-2 max-w-xs text-sm text-ink/60">
                  Thanks for reaching out. Our team at {SITE.supportEmail} will
                  get back to you shortly.
                </p>
                <button
                  onClick={() => setStatus("idle")}
                  className="mt-6 rounded-full border border-ink/15 px-5 py-2.5 text-sm font-semibold hover:bg-sand transition-colors"
                >
                  Send another
                </button>
              </div>
            ) : (
              <form onSubmit={submit} className="space-y-4">
                <h3 className="font-display text-xl font-semibold">
                  Send a message
                </h3>
                <div className="grid gap-4 sm:grid-cols-2">
                  <input
                    placeholder="Your name"
                    value={form.name}
                    onChange={(e) =>
                      setForm({ ...form, name: e.target.value })
                    }
                    className="rounded-xl border border-sand bg-cream px-4 py-3 text-sm focus:outline-none focus:border-coral"
                  />
                  <input
                    type="email"
                    placeholder="Email address"
                    value={form.email}
                    onChange={(e) =>
                      setForm({ ...form, email: e.target.value })
                    }
                    className="rounded-xl border border-sand bg-cream px-4 py-3 text-sm focus:outline-none focus:border-coral"
                  />
                </div>
                <div>
                  <label className="mb-1.5 block text-sm font-medium text-ink/70">
                    Topic
                  </label>
                  <div className="flex flex-wrap gap-2">
                    {TOPICS.map((t) => (
                      <button
                        key={t.value}
                        type="button"
                        onClick={() => setForm({ ...form, topic: t.value })}
                        className={`rounded-full border px-4 py-2 text-sm font-medium transition-colors ${
                          form.topic === t.value
                            ? "border-coral bg-coral text-white"
                            : "border-sand hover:border-ink/25"
                        }`}
                      >
                        {t.label}
                      </button>
                    ))}
                  </div>
                </div>
                <textarea
                  placeholder="How can we help?"
                  rows={4}
                  value={form.message}
                  onChange={(e) =>
                    setForm({ ...form, message: e.target.value })
                  }
                  className="w-full resize-none rounded-xl border border-sand bg-cream px-4 py-3 text-sm focus:outline-none focus:border-coral"
                />
                {error && <p className="text-sm text-coral">{error}</p>}
                <button
                  type="submit"
                  disabled={status === "sending"}
                  className="w-full rounded-full bg-ink px-6 py-3.5 text-sm font-semibold text-cream hover:bg-ink/90 transition-colors disabled:opacity-60"
                >
                  {status === "sending" ? "Sending…" : "Send message"}
                </button>
                <p className="text-center text-xs text-ink/40">
                  Or call {SITE.contactPhone} · {SITE.supportEmail}
                </p>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
