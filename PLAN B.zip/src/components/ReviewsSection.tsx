"use client";

import { useState } from "react";
import type { ReviewDTO } from "@/lib/types";
import { Stars, StarIcon } from "./Icons";

function initials(name: string) {
  return name
    .split(" ")
    .map((w) => w[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();
}

const AVATAR_COLORS = ["#ff5a5f", "#6b4de6", "#f0a500", "#2dd4bf", "#f472b6"];

export function ReviewsSection({
  productId,
  initialReviews,
  rating,
}: {
  productId: number;
  initialReviews: ReviewDTO[];
  rating: number;
}) {
  const [reviews, setReviews] = useState<ReviewDTO[]>(initialReviews);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({
    author: "",
    handle: "",
    rating: 5,
    title: "",
    body: "",
  });
  const [hover, setHover] = useState(0);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");

  const avg =
    reviews.length > 0
      ? reviews.reduce((s, r) => s + r.rating, 0) / reviews.length
      : rating / 10;

  const distribution = [5, 4, 3, 2, 1].map((star) => ({
    star,
    count: reviews.filter((r) => r.rating === star).length,
  }));

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    if (!form.author || !form.title || !form.body) {
      setError("Please fill in your name, a title, and your review.");
      return;
    }
    setSubmitting(true);
    try {
      const res = await fetch("/api/reviews", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...form, productId }),
      });
      const data = await res.json();
      if (data.ok) {
        setReviews((prev) => [data.review, ...prev]);
        setForm({ author: "", handle: "", rating: 5, title: "", body: "" });
        setShowForm(false);
      } else {
        setError(data.error || "Something went wrong.");
      }
    } catch {
      setError("Network error. Please try again.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <section className="border-t border-sand pt-14">
      <div className="grid gap-10 lg:grid-cols-[320px_1fr]">
        {/* Summary */}
        <div className="lg:sticky lg:top-24 lg:self-start">
          <h2 className="font-display text-3xl font-semibold">
            Creator reviews
          </h2>
          <div className="mt-4 flex items-end gap-3">
            <span className="font-display text-5xl font-bold">
              {avg.toFixed(1)}
            </span>
            <div className="mb-1">
              <Stars rating={avg} className="[&_svg]:w-4 [&_svg]:h-4" />
              <p className="mt-0.5 text-sm text-ink/50">
                {reviews.length}{" "}
                {reviews.length === 1 ? "review" : "reviews"}
              </p>
            </div>
          </div>

          <div className="mt-5 space-y-2">
            {distribution.map((d) => (
              <div key={d.star} className="flex items-center gap-2 text-sm">
                <span className="w-3 text-ink/50">{d.star}</span>
                <StarIcon className="w-3 h-3 text-coral" />
                <div className="h-2 flex-1 overflow-hidden rounded-full bg-sand">
                  <div
                    className="h-full rounded-full bg-coral"
                    style={{
                      width: `${
                        reviews.length
                          ? (d.count / reviews.length) * 100
                          : 0
                      }%`,
                    }}
                  />
                </div>
                <span className="w-5 text-right text-ink/40">{d.count}</span>
              </div>
            ))}
          </div>

          <button
            onClick={() => setShowForm((s) => !s)}
            className="mt-6 w-full rounded-full border border-ink/15 py-3 text-sm font-semibold hover:bg-sand transition-colors"
          >
            {showForm ? "Cancel" : "Write a review"}
          </button>
        </div>

        {/* List + form */}
        <div>
          {showForm && (
            <form
              onSubmit={handleSubmit}
              className="mb-8 rounded-2xl border border-sand bg-blush/30 p-6 animate-fade-up"
            >
              <h3 className="font-display text-lg font-semibold">
                Share your experience
              </h3>
              <div className="mt-4 grid gap-4 sm:grid-cols-2">
                <input
                  placeholder="Your name *"
                  value={form.author}
                  onChange={(e) =>
                    setForm({ ...form, author: e.target.value })
                  }
                  className="rounded-xl border border-sand bg-cream px-4 py-3 text-sm focus:outline-none focus:border-coral"
                />
                <input
                  placeholder="@handle"
                  value={form.handle}
                  onChange={(e) =>
                    setForm({ ...form, handle: e.target.value })
                  }
                  className="rounded-xl border border-sand bg-cream px-4 py-3 text-sm focus:outline-none focus:border-coral"
                />
              </div>
              <div className="mt-4 flex items-center gap-2">
                <span className="text-sm text-ink/60">Rating:</span>
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    type="button"
                    onMouseEnter={() => setHover(star)}
                    onMouseLeave={() => setHover(0)}
                    onClick={() => setForm({ ...form, rating: star })}
                    aria-label={`${star} stars`}
                  >
                    <StarIcon
                      className={`w-6 h-6 transition-colors ${
                        star <= (hover || form.rating)
                          ? "text-coral"
                          : "text-sand"
                      }`}
                    />
                  </button>
                ))}
              </div>
              <input
                placeholder="Review title *"
                value={form.title}
                onChange={(e) => setForm({ ...form, title: e.target.value })}
                className="mt-4 w-full rounded-xl border border-sand bg-cream px-4 py-3 text-sm focus:outline-none focus:border-coral"
              />
              <textarea
                placeholder="Tell other creators how it went... *"
                value={form.body}
                onChange={(e) => setForm({ ...form, body: e.target.value })}
                rows={4}
                className="mt-4 w-full rounded-xl border border-sand bg-cream px-4 py-3 text-sm focus:outline-none focus:border-coral resize-none"
              />
              {error && (
                <p className="mt-3 text-sm text-coral">{error}</p>
              )}
              <button
                type="submit"
                disabled={submitting}
                className="mt-4 rounded-full bg-ink px-6 py-3 text-sm font-semibold text-cream hover:bg-ink/90 transition-colors disabled:opacity-60"
              >
                {submitting ? "Posting…" : "Post review"}
              </button>
            </form>
          )}

          {reviews.length === 0 ? (
            <div className="rounded-2xl border border-dashed border-sand py-16 text-center">
              <p className="font-display text-lg font-semibold">
                No reviews yet
              </p>
              <p className="mt-1 text-sm text-ink/50">
                Be the first to share your experience.
              </p>
            </div>
          ) : (
            <div className="space-y-6">
              {reviews.map((r, i) => (
                <div
                  key={r.id}
                  className="rounded-2xl border border-sand bg-cream p-6 animate-fade-up"
                  style={{ animationDelay: `${Math.min(i, 6) * 40}ms` }}
                >
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex items-center gap-3">
                      <div
                        className="flex h-11 w-11 items-center justify-center rounded-full text-sm font-bold text-white"
                        style={{
                          backgroundColor:
                            AVATAR_COLORS[i % AVATAR_COLORS.length],
                        }}
                      >
                        {initials(r.author)}
                      </div>
                      <div>
                        <p className="font-semibold leading-tight">
                          {r.author}
                        </p>
                        <p className="text-xs text-ink/45">{r.handle}</p>
                      </div>
                    </div>
                    <Stars rating={r.rating} />
                  </div>
                  <h4 className="mt-4 font-display text-lg font-semibold">
                    {r.title}
                  </h4>
                  <p className="mt-1.5 text-ink/70 leading-relaxed">
                    {r.body}
                  </p>
                  <p className="mt-3 text-xs text-ink/40">
                    Verified purchase ·{" "}
                    {new Date(r.createdAt).toLocaleDateString("en-US", {
                      month: "short",
                      day: "numeric",
                      year: "numeric",
                    })}
                  </p>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
