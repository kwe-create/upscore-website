"use client";

import Link from "next/link";
import Image from "next/image";
import { useState } from "react";
import { useCart } from "./CartProvider";
import { formatPrice, billingLabel } from "@/lib/format";
import { CheckIcon, ArrowRight, CartIcon } from "./Icons";
import { SITE } from "@/lib/site";

type Step = "details" | "payment" | "done";
type PayMethod = "paypal" | "card";

export function CheckoutClient() {
  const { items, subtotal, clearCart, hydrated } = useCart();
  const [step, setStep] = useState<Step>("details");
  const [payMethod, setPayMethod] = useState<PayMethod>("paypal");
  const [form, setForm] = useState({
    email: "",
    fullName: "",
    company: "",
    card: "",
    exp: "",
    cvc: "",
    paypalEmail: "",
  });
  const [promo, setPromo] = useState("");
  const [appliedPromo, setAppliedPromo] = useState<{
    code: string;
    rate: number;
  } | null>(null);
  const [promoMsg, setPromoMsg] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);
  const [order, setOrder] = useState<{
    reference: string;
    total: number;
    discount: number;
    paymentMethod: PayMethod;
  } | null>(null);

  const discount = appliedPromo ? Math.round(subtotal * appliedPromo.rate) : 0;
  const tax = Math.round((subtotal - discount) * 0.0);
  const total = subtotal - discount + tax;

  const applyPromo = async () => {
    const code = promo.trim().toUpperCase();
    if (!code) return;
    try {
      const res = await fetch(`/api/checkout?promo=${encodeURIComponent(code)}`);
      const data = await res.json();
      if (data.valid) {
        setAppliedPromo({ code, rate: data.rate });
        setPromoMsg(`Code applied — ${Math.round(data.rate * 100)}% off!`);
      } else {
        setAppliedPromo(null);
        setPromoMsg("That code isn't valid. Try CREATOR10.");
      }
    } catch {
      setPromoMsg("Couldn't check that code.");
    }
  };

  const validateDetails = () => {
    const e: Record<string, string> = {};
    if (!form.fullName.trim()) e.fullName = "Required";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email))
      e.email = "Enter a valid email";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const validatePayment = () => {
    const e: Record<string, string> = {};
    if (payMethod === "card") {
      if (form.card.replace(/\s/g, "").length < 12)
        e.card = "Enter a card number";
      if (!/^\d{2}\s*\/\s*\d{2}$/.test(form.exp)) e.exp = "MM/YY";
      if (form.cvc.length < 3) e.cvc = "CVC";
    } else {
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.paypalEmail))
        e.paypalEmail = "Enter your PayPal email";
    }
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const placeOrder = async () => {
    if (!validatePayment()) return;
    setSubmitting(true);
    try {
      const res = await fetch("/api/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email: form.email,
          fullName: form.fullName,
          company: form.company,
          items,
          promo: appliedPromo?.code,
          paymentMethod: payMethod,
          payerEmail: payMethod === "paypal" ? form.paypalEmail : undefined,
        }),
      });
      const data = await res.json();
      if (data.ok) {
        setOrder({
          reference: data.reference,
          total: data.total,
          discount: data.discount,
          paymentMethod: data.paymentMethod === "paypal" ? "paypal" : "card",
        });
        setStep("done");
        clearCart();
      }
    } finally {
      setSubmitting(false);
    }
  };

  if (!hydrated) {
    return (
      <div className="mx-auto max-w-7xl px-5 sm:px-8 py-24 text-center text-ink/40">
        Loading…
      </div>
    );
  }

  if (step === "done" && order) {
    return (
      <div className="mx-auto max-w-2xl px-5 sm:px-8 py-24 text-center">
        <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-full bg-coral/15 text-coral animate-fade-up">
          <CheckIcon className="w-10 h-10" />
        </div>
        <h1 className="mt-6 font-display text-4xl font-semibold animate-fade-up delay-100">
          You&apos;re all set! 🎉
        </h1>
        <p className="mt-3 text-ink/60 animate-fade-up delay-200">
          Order <span className="font-semibold text-ink">{order.reference}</span>{" "}
          is confirmed. We&apos;ve sent a receipt to{" "}
          <span className="font-semibold text-ink">{form.email}</span>. Your
          onboarding kicks off within 48 hours.
        </p>
        {order.paymentMethod === "paypal" && (
          <div className="mx-auto mt-6 max-w-md rounded-2xl border border-sand bg-blush/40 px-6 py-5 text-left text-sm text-ink/75 animate-fade-up delay-200">
            <p className="font-semibold text-ink">
              Complete your PayPal payment
            </p>
            <p className="mt-1">
              Send{" "}
              <span className="font-semibold text-ink">
                {formatPrice(order.total)}
              </span>{" "}
              to{" "}
              <a
                href={`https://www.paypal.com/paypalme/${SITE.paypalEmail}`}
                target="_blank"
                rel="noopener noreferrer"
                className="font-semibold text-coral hover:underline break-all"
              >
                {SITE.paypalEmail}
              </a>{" "}
              and include reference{" "}
              <span className="font-semibold text-ink">{order.reference}</span>{" "}
              in the note.
            </p>
            <p className="mt-2 text-xs text-ink/55">
              Need help? Call {SITE.contactPhone} or email {SITE.supportEmail}.
            </p>
          </div>
        )}
        <div className="mt-6 inline-flex items-baseline gap-2 rounded-2xl bg-blush/40 px-6 py-4 animate-fade-up delay-300">
          <span className="text-sm text-ink/60">
            {order.paymentMethod === "paypal" ? "Amount due" : "Total charged"}
          </span>
          <span className="font-display text-2xl font-semibold">
            {formatPrice(order.total)}
          </span>
        </div>
        <div className="mt-8 flex justify-center gap-4 animate-fade-up delay-400">
          <Link
            href="/shop"
            className="rounded-full bg-ink px-6 py-3 text-sm font-semibold text-cream hover:bg-ink/90 transition-colors"
          >
            Keep shopping
          </Link>
          <Link
            href="/"
            className="rounded-full border border-ink/15 px-6 py-3 text-sm font-semibold hover:bg-sand transition-colors"
          >
            Back home
          </Link>
        </div>
      </div>
    );
  }

  if (items.length === 0) {
    return (
      <div className="mx-auto max-w-2xl px-5 sm:px-8 py-24 text-center">
        <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-full bg-sand">
          <CartIcon className="w-9 h-9 text-ink/40" />
        </div>
        <h1 className="mt-6 font-display text-3xl font-semibold">
          Your cart is empty
        </h1>
        <p className="mt-2 text-ink/60">
          Add a plan before heading to checkout.
        </p>
        <Link
          href="/shop"
          className="mt-6 inline-flex items-center gap-2 rounded-full bg-coral px-6 py-3 text-sm font-semibold text-white hover:bg-coral/90 transition-colors"
        >
          Browse plans <ArrowRight className="w-4 h-4" />
        </Link>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-6xl px-5 sm:px-8 py-10">
      <h1 className="font-display text-4xl font-semibold tracking-tight">
        Checkout
      </h1>

      {/* Steps indicator */}
      <div className="mt-4 flex items-center gap-3 text-sm">
        <StepDot active={step === "details"} done={step === "payment"} label="1. Details" />
        <span className="h-px w-8 bg-sand" />
        <StepDot active={step === "payment"} done={false} label="2. Payment" />
      </div>

      <div className="mt-8 grid gap-10 lg:grid-cols-[1fr_380px]">
        {/* Form */}
        <div>
          {step === "details" && (
            <div className="space-y-5 animate-fade-up">
              <h2 className="font-display text-2xl font-semibold">
                Contact details
              </h2>
              <Field
                label="Full name"
                value={form.fullName}
                onChange={(v) => setForm({ ...form, fullName: v })}
                error={errors.fullName}
                placeholder="Alex Rivera"
              />
              <Field
                label="Email address"
                type="email"
                value={form.email}
                onChange={(v) => setForm({ ...form, email: v })}
                error={errors.email}
                placeholder="you@creator.com"
              />
              <Field
                label="Brand / company (optional)"
                value={form.company}
                onChange={(v) => setForm({ ...form, company: v })}
                placeholder="Rivera Studio"
              />
              <button
                onClick={() => validateDetails() && setStep("payment")}
                className="mt-2 inline-flex items-center gap-2 rounded-full bg-ink px-7 py-3.5 text-sm font-semibold text-cream hover:bg-ink/90 transition-all hover:gap-3"
              >
                Continue to payment <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          )}

          {step === "payment" && (
            <div className="space-y-5 animate-fade-up">
              <div className="flex items-center justify-between">
                <h2 className="font-display text-2xl font-semibold">Payment</h2>
                <button
                  onClick={() => setStep("details")}
                  className="text-sm font-medium text-coral hover:underline"
                >
                  Edit details
                </button>
              </div>
              {/* Payment method selector */}
              <div className="grid gap-3 sm:grid-cols-2">
                <button
                  type="button"
                  onClick={() => setPayMethod("paypal")}
                  className={`flex items-start gap-3 rounded-2xl border p-4 text-left transition-all ${
                    payMethod === "paypal"
                      ? "border-coral bg-blush/40 ring-1 ring-coral"
                      : "border-sand hover:border-ink/25"
                  }`}
                >
                  <span
                    className={`mt-0.5 flex h-5 w-5 flex-shrink-0 items-center justify-center rounded-full border ${
                      payMethod === "paypal"
                        ? "border-coral bg-coral text-white"
                        : "border-ink/30"
                    }`}
                  >
                    {payMethod === "paypal" && <CheckIcon className="w-3 h-3" />}
                  </span>
                  <span>
                    <span className="block text-sm font-semibold">
                      Option A · PayPal
                    </span>
                    <span className="block text-xs text-ink/55">
                      Pay to {SITE.paypalEmail}
                    </span>
                  </span>
                </button>
                <button
                  type="button"
                  onClick={() => setPayMethod("card")}
                  className={`flex items-start gap-3 rounded-2xl border p-4 text-left transition-all ${
                    payMethod === "card"
                      ? "border-coral bg-blush/40 ring-1 ring-coral"
                      : "border-sand hover:border-ink/25"
                  }`}
                >
                  <span
                    className={`mt-0.5 flex h-5 w-5 flex-shrink-0 items-center justify-center rounded-full border ${
                      payMethod === "card"
                        ? "border-coral bg-coral text-white"
                        : "border-ink/30"
                    }`}
                  >
                    {payMethod === "card" && <CheckIcon className="w-3 h-3" />}
                  </span>
                  <span>
                    <span className="block text-sm font-semibold">
                      Option B · Card
                    </span>
                    <span className="block text-xs text-ink/55">
                      Visa, Mastercard, Amex
                    </span>
                  </span>
                </button>
              </div>

              {payMethod === "paypal" ? (
                <div className="space-y-4 animate-fade-up">
                  <div className="rounded-xl border border-sand bg-blush/40 px-4 py-4 text-sm text-ink/75">
                    <p className="font-semibold text-ink">
                      Pay {formatPrice(total)} via PayPal
                    </p>
                    <p className="mt-1">
                      Send payment to{" "}
                      <a
                        href={`https://www.paypal.com/paypalme/${SITE.paypalEmail}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="font-semibold text-coral hover:underline break-all"
                      >
                        {SITE.paypalEmail}
                      </a>
                      . Add your order email in the PayPal note so we can match
                      it. We confirm and start onboarding within 48 hours.
                    </p>
                    <p className="mt-2 text-xs text-ink/50">
                      Questions? Contact us on {SITE.contactPhone} or email{" "}
                      {SITE.supportEmail}.
                    </p>
                  </div>
                  <Field
                    label="Your PayPal email"
                    type="email"
                    value={form.paypalEmail}
                    onChange={(v) => setForm({ ...form, paypalEmail: v })}
                    error={errors.paypalEmail}
                    placeholder="you@paypal.com"
                  />
                </div>
              ) : (
                <div className="space-y-4 animate-fade-up">
                  <div className="rounded-xl bg-blush/40 px-4 py-3 text-sm text-ink/70">
                    Demo checkout — no real card is charged. Use any numbers.
                  </div>
                  <Field
                    label="Card number"
                    value={form.card}
                    onChange={(v) =>
                      setForm({
                        ...form,
                        card: v
                          .replace(/\D/g, "")
                          .slice(0, 16)
                          .replace(/(.{4})/g, "$1 ")
                          .trim(),
                      })
                    }
                    error={errors.card}
                    placeholder="4242 4242 4242 4242"
                  />
                  <div className="grid grid-cols-2 gap-4">
                    <Field
                      label="Expiry"
                      value={form.exp}
                      onChange={(v) => {
                        const digits = v.replace(/\D/g, "").slice(0, 4);
                        const formatted =
                          digits.length > 2
                            ? `${digits.slice(0, 2)}/${digits.slice(2)}`
                            : digits;
                        setForm({ ...form, exp: formatted });
                      }}
                      error={errors.exp}
                      placeholder="12/28"
                    />
                    <Field
                      label="CVC"
                      value={form.cvc}
                      onChange={(v) =>
                        setForm({
                          ...form,
                          cvc: v.replace(/\D/g, "").slice(0, 4),
                        })
                      }
                      error={errors.cvc}
                      placeholder="123"
                    />
                  </div>
                </div>
              )}

              <button
                onClick={placeOrder}
                disabled={submitting}
                className="mt-2 inline-flex w-full items-center justify-center gap-2 rounded-full bg-coral px-7 py-4 text-sm font-semibold text-white hover:bg-coral/90 transition-all disabled:opacity-60"
              >
                {submitting
                  ? "Processing…"
                  : payMethod === "paypal"
                    ? `Confirm PayPal order · ${formatPrice(total)}`
                    : `Pay ${formatPrice(total)}`}
              </button>
              <p className="text-center text-xs text-ink/40">
                🔒 Secured & encrypted. Cancel anytime.
              </p>
            </div>
          )}
        </div>

        {/* Order summary */}
        <aside className="lg:sticky lg:top-24 lg:self-start">
          <div className="rounded-2xl border border-sand bg-cream p-6">
            <h2 className="font-display text-lg font-semibold">Order summary</h2>
            <div className="mt-5 space-y-4">
              {items.map((item) => (
                <div key={item.productId} className="flex gap-3">
                  <div className="relative h-16 w-16 flex-shrink-0 overflow-hidden rounded-lg bg-sand">
                    <Image
                      src={item.image}
                      alt={item.name}
                      fill
                      sizes="64px"
                      className="object-cover"
                    />
                    <span className="absolute -right-1.5 -top-1.5 flex h-5 w-5 items-center justify-center rounded-full bg-ink text-[10px] font-bold text-cream">
                      {item.quantity}
                    </span>
                  </div>
                  <div className="flex flex-1 flex-col justify-center">
                    <p className="text-sm font-semibold leading-tight">
                      {item.name}
                    </p>
                    <p className="text-xs text-ink/45">
                      {formatPrice(item.price)} {billingLabel(item.billing)}
                    </p>
                  </div>
                  <span className="self-center text-sm font-semibold">
                    {formatPrice(item.price * item.quantity)}
                  </span>
                </div>
              ))}
            </div>

            {/* Promo */}
            <div className="mt-5 border-t border-sand pt-5">
              <div className="flex gap-2">
                <input
                  value={promo}
                  onChange={(e) => setPromo(e.target.value)}
                  placeholder="Promo code"
                  className="min-w-0 flex-1 rounded-full border border-sand bg-cream px-4 py-2.5 text-sm focus:outline-none focus:border-coral uppercase"
                />
                <button
                  onClick={applyPromo}
                  className="rounded-full bg-ink px-4 py-2.5 text-sm font-semibold text-cream hover:bg-ink/90 transition-colors"
                >
                  Apply
                </button>
              </div>
              {promoMsg && (
                <p
                  className={`mt-2 text-xs ${
                    appliedPromo ? "text-plum" : "text-coral"
                  }`}
                >
                  {promoMsg}
                </p>
              )}
              {!promoMsg && (
                <p className="mt-2 text-xs text-ink/40">
                  Try <span className="font-semibold">CREATOR10</span> for 10% off
                </p>
              )}
            </div>

            {/* Totals */}
            <div className="mt-5 space-y-2 border-t border-sand pt-5 text-sm">
              <div className="flex justify-between text-ink/60">
                <span>Subtotal</span>
                <span>{formatPrice(subtotal)}</span>
              </div>
              {discount > 0 && (
                <div className="flex justify-between text-plum">
                  <span>Discount ({appliedPromo?.code})</span>
                  <span>−{formatPrice(discount)}</span>
                </div>
              )}
              <div className="flex justify-between text-ink/60">
                <span>Taxes</span>
                <span>Calculated later</span>
              </div>
              <div className="flex items-baseline justify-between border-t border-sand pt-3">
                <span className="font-semibold">Total due</span>
                <span className="font-display text-2xl font-semibold">
                  {formatPrice(total)}
                </span>
              </div>
            </div>
          </div>
          <Link
            href="/shop"
            className="mt-4 block text-center text-sm text-ink/50 hover:text-ink transition-colors"
          >
            ← Continue shopping
          </Link>
        </aside>
      </div>
    </div>
  );
}

function StepDot({
  active,
  done,
  label,
}: {
  active: boolean;
  done: boolean;
  label: string;
}) {
  return (
    <span
      className={`font-medium ${
        active ? "text-ink" : done ? "text-plum" : "text-ink/40"
      }`}
    >
      {label}
    </span>
  );
}

function Field({
  label,
  value,
  onChange,
  error,
  placeholder,
  type = "text",
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  error?: string;
  placeholder?: string;
  type?: string;
}) {
  return (
    <div>
      <label className="mb-1.5 block text-sm font-medium text-ink/70">
        {label}
      </label>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className={`w-full rounded-xl border bg-cream px-4 py-3 text-sm focus:outline-none transition-colors ${
          error ? "border-coral" : "border-sand focus:border-coral"
        }`}
      />
      {error && <p className="mt-1 text-xs text-coral">{error}</p>}
    </div>
  );
}
