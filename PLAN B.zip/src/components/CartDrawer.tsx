"use client";

import Link from "next/link";
import Image from "next/image";
import { useEffect } from "react";
import { useCart } from "./CartProvider";
import { CloseIcon, MinusIcon, PlusIcon, ArrowRight, CartIcon } from "./Icons";
import { formatPrice, billingLabel } from "@/lib/format";

const FREE_THRESHOLD = 49900; // $499

export function CartDrawer() {
  const {
    items,
    isOpen,
    closeCart,
    subtotal,
    setQuantity,
    removeItem,
    count,
  } = useCart();

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
    return () => {
      document.body.style.overflow = "";
    };
  }, [isOpen]);

  const remaining = Math.max(0, FREE_THRESHOLD - subtotal);
  const progress = Math.min(100, (subtotal / FREE_THRESHOLD) * 100);

  return (
    <>
      <div
        onClick={closeCart}
        className={`fixed inset-0 z-50 bg-ink/40 backdrop-blur-sm transition-opacity duration-300 ${
          isOpen ? "opacity-100" : "opacity-0 pointer-events-none"
        }`}
      />
      <aside
        className={`fixed right-0 top-0 z-50 flex h-full w-full max-w-md flex-col bg-cream shadow-2xl transition-transform duration-400 ease-[cubic-bezier(0.22,1,0.36,1)] ${
          isOpen ? "translate-x-0" : "translate-x-full"
        }`}
        aria-hidden={!isOpen}
      >
        <div className="flex items-center justify-between px-6 py-5 border-b border-sand">
          <h2 className="font-display text-xl font-semibold">
            Your Cart {count > 0 && <span className="text-ink/40">({count})</span>}
          </h2>
          <button
            onClick={closeCart}
            aria-label="Close cart"
            className="flex h-9 w-9 items-center justify-center rounded-full hover:bg-sand transition-colors"
          >
            <CloseIcon className="w-5 h-5" />
          </button>
        </div>

        {items.length > 0 && (
          <div className="px-6 py-4 border-b border-sand bg-blush/40">
            {remaining > 0 ? (
              <p className="text-sm text-ink/70">
                Add <span className="font-semibold text-coral">{formatPrice(remaining)}</span> more for a{" "}
                <span className="font-semibold">free strategy audit</span> 🎁
              </p>
            ) : (
              <p className="text-sm font-semibold text-coral">
                🎉 You unlocked a free strategy audit!
              </p>
            )}
            <div className="mt-2 h-1.5 w-full rounded-full bg-sand overflow-hidden">
              <div
                className="h-full rounded-full bg-coral transition-all duration-500"
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>
        )}

        {items.length === 0 ? (
          <div className="flex flex-1 flex-col items-center justify-center gap-4 px-6 text-center">
            <div className="flex h-20 w-20 items-center justify-center rounded-full bg-sand">
              <CartIcon className="w-9 h-9 text-ink/40" />
            </div>
            <div>
              <p className="font-display text-lg font-semibold">Your cart is empty</p>
              <p className="mt-1 text-sm text-ink/50">
                Ready to grow? Explore our plans.
              </p>
            </div>
            <Link
              href="/shop"
              onClick={closeCart}
              className="mt-2 inline-flex items-center gap-2 rounded-full bg-ink px-6 py-3 text-sm font-semibold text-cream hover:bg-ink/90 transition-colors"
            >
              Browse plans <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        ) : (
          <>
            <div className="flex-1 overflow-y-auto px-6 py-4 space-y-5">
              {items.map((item) => (
                <div key={item.productId} className="flex gap-4">
                  <Link
                    href={`/product/${item.slug}`}
                    onClick={closeCart}
                    className="relative h-20 w-20 flex-shrink-0 overflow-hidden rounded-xl bg-sand"
                  >
                    <Image
                      src={item.image}
                      alt={item.name}
                      fill
                      sizes="80px"
                      className="object-cover"
                    />
                  </Link>
                  <div className="flex flex-1 flex-col">
                    <div className="flex justify-between gap-2">
                      <Link
                        href={`/product/${item.slug}`}
                        onClick={closeCart}
                        className="text-sm font-semibold leading-snug hover:text-coral transition-colors"
                      >
                        {item.name}
                      </Link>
                      <button
                        onClick={() => removeItem(item.productId)}
                        className="text-ink/40 hover:text-coral transition-colors"
                        aria-label="Remove"
                      >
                        <CloseIcon className="w-4 h-4" />
                      </button>
                    </div>
                    <p className="text-xs text-ink/50">
                      {formatPrice(item.price)}
                      <span className="ml-1">{billingLabel(item.billing)}</span>
                    </p>
                    <div className="mt-auto flex items-center justify-between">
                      <div className="flex items-center rounded-full border border-sand">
                        <button
                          onClick={() => setQuantity(item.productId, item.quantity - 1)}
                          className="flex h-7 w-7 items-center justify-center rounded-full hover:bg-sand transition-colors"
                          aria-label="Decrease"
                        >
                          <MinusIcon className="w-3.5 h-3.5" />
                        </button>
                        <span className="w-7 text-center text-sm font-medium">
                          {item.quantity}
                        </span>
                        <button
                          onClick={() => setQuantity(item.productId, item.quantity + 1)}
                          className="flex h-7 w-7 items-center justify-center rounded-full hover:bg-sand transition-colors"
                          aria-label="Increase"
                        >
                          <PlusIcon className="w-3.5 h-3.5" />
                        </button>
                      </div>
                      <span className="text-sm font-semibold">
                        {formatPrice(item.price * item.quantity)}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="border-t border-sand px-6 py-5 space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm text-ink/60">Subtotal</span>
                <span className="font-display text-xl font-semibold">
                  {formatPrice(subtotal)}
                </span>
              </div>
              <p className="text-xs text-ink/40">
                Taxes calculated at checkout. Cancel anytime.
              </p>
              <Link
                href="/checkout"
                onClick={closeCart}
                className="flex w-full items-center justify-center gap-2 rounded-full bg-coral px-6 py-4 text-sm font-semibold text-white hover:bg-coral/90 transition-all hover:gap-3"
              >
                Checkout <ArrowRight className="w-4 h-4" />
              </Link>
              <button
                onClick={closeCart}
                className="w-full text-center text-sm text-ink/50 hover:text-ink transition-colors"
              >
                Continue shopping
              </button>
            </div>
          </>
        )}
      </aside>
    </>
  );
}
