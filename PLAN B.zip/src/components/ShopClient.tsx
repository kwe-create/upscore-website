"use client";

import { useState, useMemo } from "react";
import type { ProductDTO } from "@/lib/types";
import { ProductCard } from "./ProductCard";
import { CloseIcon } from "./Icons";

const COLLECTIONS = ["Growth", "Content", "Strategy"];
const BILLING = [
  { value: "monthly", label: "Monthly" },
  { value: "one-time", label: "One-time" },
  { value: "package", label: "Package" },
];
const PLATFORMS = ["Instagram", "TikTok", "YouTube", "LinkedIn"];
const SORTS = [
  { value: "featured", label: "Featured" },
  { value: "popular", label: "Most popular" },
  { value: "rating", label: "Top rated" },
  { value: "price-asc", label: "Price: low to high" },
  { value: "price-desc", label: "Price: high to low" },
];

export function ShopClient({
  products,
  initialCollection,
}: {
  products: ProductDTO[];
  initialCollection?: string;
}) {
  const [collections, setCollections] = useState<string[]>(
    initialCollection ? [initialCollection] : [],
  );
  const [billing, setBilling] = useState<string[]>([]);
  const [platforms, setPlatforms] = useState<string[]>([]);
  const [sort, setSort] = useState("featured");
  const [mobileFiltersOpen, setMobileFiltersOpen] = useState(false);

  const toggle = (
    value: string,
    list: string[],
    setter: (v: string[]) => void,
  ) => {
    setter(
      list.includes(value)
        ? list.filter((v) => v !== value)
        : [...list, value],
    );
  };

  const filtered = useMemo(() => {
    let result = [...products];
    if (collections.length)
      result = result.filter((p) => collections.includes(p.collection));
    if (billing.length)
      result = result.filter((p) => billing.includes(p.billing));
    if (platforms.length)
      result = result.filter((p) =>
        platforms.some((pl) => p.platforms.includes(pl)),
      );

    switch (sort) {
      case "price-asc":
        result.sort((a, b) => a.price - b.price);
        break;
      case "price-desc":
        result.sort((a, b) => b.price - a.price);
        break;
      case "rating":
        result.sort((a, b) => b.rating - a.rating);
        break;
      case "popular":
        result.sort((a, b) => b.reviewCount - a.reviewCount);
        break;
      case "featured":
        result.sort(
          (a, b) => Number(b.featured) - Number(a.featured) || a.id - b.id,
        );
        break;
    }
    return result;
  }, [products, collections, billing, platforms, sort]);

  const activeCount =
    collections.length + billing.length + platforms.length;

  const clearAll = () => {
    setCollections([]);
    setBilling([]);
    setPlatforms([]);
  };

  const FilterGroup = ({
    title,
    options,
    selected,
    onToggle,
  }: {
    title: string;
    options: { value: string; label: string }[];
    selected: string[];
    onToggle: (v: string) => void;
  }) => (
    <div className="border-b border-sand pb-6">
      <h3 className="mb-3 text-sm font-semibold uppercase tracking-wider text-ink/50">
        {title}
      </h3>
      <div className="space-y-2.5">
        {options.map((opt) => (
          <label
            key={opt.value}
            className="flex cursor-pointer items-center gap-3 text-sm text-ink/80 hover:text-ink"
          >
            <span
              className={`flex h-5 w-5 items-center justify-center rounded-md border transition-colors ${
                selected.includes(opt.value)
                  ? "border-coral bg-coral text-white"
                  : "border-ink/25 bg-transparent"
              }`}
            >
              {selected.includes(opt.value) && (
                <svg viewBox="0 0 24 24" className="h-3 w-3" fill="none" stroke="currentColor" strokeWidth={3}>
                  <path d="M5 13l4 4L19 7" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              )}
            </span>
            <input
              type="checkbox"
              className="sr-only"
              checked={selected.includes(opt.value)}
              onChange={() => onToggle(opt.value)}
            />
            {opt.label}
          </label>
        ))}
      </div>
    </div>
  );

  const filterContent = (
    <div className="space-y-6">
      <FilterGroup
        title="Collection"
        options={COLLECTIONS.map((c) => ({ value: c, label: c }))}
        selected={collections}
        onToggle={(v) => toggle(v, collections, setCollections)}
      />
      <FilterGroup
        title="Billing"
        options={BILLING}
        selected={billing}
        onToggle={(v) => toggle(v, billing, setBilling)}
      />
      <FilterGroup
        title="Platform"
        options={PLATFORMS.map((p) => ({ value: p, label: p }))}
        selected={platforms}
        onToggle={(v) => toggle(v, platforms, setPlatforms)}
      />
    </div>
  );

  return (
    <div className="mx-auto max-w-7xl px-5 sm:px-8 py-10">
      <div className="mb-8">
        <span className="text-xs font-semibold uppercase tracking-wider text-plum">
          The full catalog
        </span>
        <h1 className="mt-2 font-display text-4xl font-semibold tracking-tight sm:text-5xl">
          Social media plans & services
        </h1>
        <p className="mt-3 max-w-2xl text-ink/60">
          Mix and match management, content, and strategy. Everything is
          month-to-month unless noted — no long contracts, ever.
        </p>
      </div>

      <div className="flex gap-10">
        {/* Desktop sidebar */}
        <aside className="hidden w-60 flex-shrink-0 lg:block">
          <div className="sticky top-24">
            <div className="mb-4 flex items-center justify-between">
              <h2 className="font-display text-lg font-semibold">Filters</h2>
              {activeCount > 0 && (
                <button
                  onClick={clearAll}
                  className="text-xs font-medium text-coral hover:underline"
                >
                  Clear ({activeCount})
                </button>
              )}
            </div>
            {filterContent}
          </div>
        </aside>

        {/* Main */}
        <div className="flex-1">
          <div className="mb-6 flex items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <button
                onClick={() => setMobileFiltersOpen(true)}
                className="lg:hidden inline-flex items-center gap-2 rounded-full border border-ink/15 px-4 py-2 text-sm font-medium"
              >
                Filters
                {activeCount > 0 && (
                  <span className="flex h-5 w-5 items-center justify-center rounded-full bg-coral text-[10px] font-bold text-white">
                    {activeCount}
                  </span>
                )}
              </button>
              <p className="text-sm text-ink/50">
                {filtered.length}{" "}
                {filtered.length === 1 ? "result" : "results"}
              </p>
            </div>
            <div className="flex items-center gap-2">
              <label className="hidden sm:block text-sm text-ink/50">
                Sort
              </label>
              <select
                value={sort}
                onChange={(e) => setSort(e.target.value)}
                className="rounded-full border border-ink/15 bg-cream px-4 py-2 text-sm font-medium focus:outline-none focus:border-coral cursor-pointer"
              >
                {SORTS.map((s) => (
                  <option key={s.value} value={s.value}>
                    {s.label}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {filtered.length === 0 ? (
            <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-sand py-24 text-center">
              <p className="font-display text-xl font-semibold">
                No plans match those filters
              </p>
              <p className="mt-1 text-sm text-ink/50">
                Try clearing some filters to see more.
              </p>
              <button
                onClick={clearAll}
                className="mt-4 rounded-full bg-ink px-5 py-2.5 text-sm font-semibold text-cream"
              >
                Clear filters
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-x-6 gap-y-10 md:grid-cols-2 xl:grid-cols-3">
              {filtered.map((p, i) => (
                <ProductCard key={p.id} product={p} index={i} />
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Mobile filters drawer */}
      {mobileFiltersOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div
            className="absolute inset-0 bg-ink/40 backdrop-blur-sm animate-fade-in"
            onClick={() => setMobileFiltersOpen(false)}
          />
          <div className="absolute left-0 top-0 h-full w-80 max-w-[85%] overflow-y-auto bg-cream p-6 shadow-2xl animate-slide-in">
            <div className="mb-6 flex items-center justify-between">
              <h2 className="font-display text-xl font-semibold">Filters</h2>
              <button
                onClick={() => setMobileFiltersOpen(false)}
                className="flex h-9 w-9 items-center justify-center rounded-full hover:bg-sand"
              >
                <CloseIcon className="w-5 h-5" />
              </button>
            </div>
            {filterContent}
            <div className="mt-6 flex gap-3">
              <button
                onClick={clearAll}
                className="flex-1 rounded-full border border-ink/15 py-3 text-sm font-semibold"
              >
                Clear
              </button>
              <button
                onClick={() => setMobileFiltersOpen(false)}
                className="flex-1 rounded-full bg-coral py-3 text-sm font-semibold text-white"
              >
                Show {filtered.length}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
